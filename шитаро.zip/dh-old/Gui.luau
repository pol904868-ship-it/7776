--[[

90% Was made by me but Allguns, AutoShoot, AutoStomp, AllGuns, AntiStomp,Flashback, AutoReload, Auto Armor were all made by diwness
Anything that was obv made by ai wasnt me(Nazzy) was made by dwiness


]]





function LPH_NO_VIRTUALIZE(f) return f end;
print("niggerniggerblackjackassnigger")
local PuppyWare = {
    Combat = {
        rage_bot = {
            Enabled = false;
            Keybind = "C";
            Prediction = 0;
            Hit_part = "Head";
            Rage = {
                Fire_rate = "0.0000000001";
                Bullet_Manipulation = false; 
                Wallbang = false;
                Kill_Aura = false;
                Auto_Shoot = false;
                Auto_Stomp = false;
                All_Guns = true;
                All_Guns_Key = "Z";
                Anti_Stomp = false;
                Flashback = false;
                Auto_Reload = false;
                Reload_Method = "Normal";
                KeepInv = false
            };
            Misc = {
                Auto_Select = false;
                NoSlowDown = false;
                NoJumpCoolDown = false;
                BunnyHop = false;
                Checks = {
                    Un_Target = {
                        Not_Visible = false;
                        Dead = false
                    };
                    Ignore = {
                        Not_Visible = false;
                        Void = false;
                        Dead = false
                    }
                }
            }
        }
    };
    HvH = {
        Antis = {
            Modes = "Random";
            ServerDesynchronization = true;
            Key = "B"
        };
    };
    Visualization = {
        Fov = {
            Properties = {
                Visible = false;
                Radius = 100;
                Color = Color3.fromRGB(173, 216, 230);
                Transparency = 1;
            }
        };
        Crosshair = {
            Global = {
                Enabled = false;
                Orgin = 'Mouse';
                Pos = Vector2.new(0, 0)
            };
        
            Settings = {
                Width = 1.5;
                Length = 10;
                Radius = 11;
                Color = Color3.fromRGB(173, 216, 230)
            };
        
            Effects = {
                Spin = false;
                Speed = 150;
                Angle = 340;
                Curve = Enum.EasingStyle.Sine
            };
        
            Animate = {
                Enabled = false;
                Speed = 2;
                MinSize = 5;
                MaxSize = 15;
            }        
        };
        On_Target = {
            Highlight = {Enabled = false; Color = Color3.fromRGB(173, 216, 230); Outline = Color3.fromRGB(1, 73, 97)};
            Snapline = {Enabled = false; Color = Color3.fromRGB(173, 216, 230); Thickness = 1};
            Tracer = {Enabled = true; Color = Color3.fromRGB(255, 0, 0); Thickness = 2};
            Notifications = {Enabled = true}
        }
    };
    Misc = {
        player = {
			SpeedEnabled = false,
			Speed = 32,
			SpeedKey = "X",

            FlyEnabled = true,
			FlySpeed = 400,
			FlyKey = "X",
            
            AutoArmorEnabled = false,
            AutoFArmorEnabled = false,
            ArmorThreshold = 75,
            FArmorThreshold = 75
        }
    };
    Visuals = {
        player_esp = {
            Enabled = false,
            Teamcheck = false,
            Distance_Check = 100000,
            Measurement = "Meters", -- "Studs" or "Meters"

            Highlight = false,
            Highlight_Accent = Color3.fromRGB(173, 216, 230),

            Boxes = false,
            Types = "Full", -- "Corner" or "Full"
            Box_Accent = Color3.fromRGB(173, 216, 230),

            Healthbar = false,
            Position = "Left", -- "Left" or "Bottom"
            Width = 1.5,
            Lerp = false,
            Healthtext = false,
            Gradient1 = Color3.fromRGB(255, 0, 0),
            Gradient2 = Color3.fromRGB(255, 150, 0),
            Gradient3 = Color3.fromRGB(0, 255, 0),

            Names = false,
            Accent = Color3.fromRGB(255, 255, 255),

            Distance = false,
            Distance_Accent = Color3.fromRGB(255, 255, 255),

            Weapon = false,
            Weapon_Accent = Color3.fromRGB(255, 255, 255),

            Arrows = false,
            Size = 15,
            Rainbow = false,
            Arrows_Accent = Color3.fromRGB(255, 255, 255),
            Points = "Three", -- "Three" or "Default"
            Radius = 100
        };
        local_player = {
        };
        world = {
        }
    }
}

getgenv().OpenACTickler = {
}


local exe_name, exe_version = identifyexecutor()
local function home999() end
local function home888() end

if exe_name ~= "Wave Windows" then
    hookfunction(home888, home999)
    if isfunctionhooked(home888) == false then
        game.Players.LocalPlayer:Destroy()
        return LPH_CRASH()
    end
end 

local function check_env(env)
    for _, func in env do
        if type(func) ~= "function" then
            continue
        end

        local functionhook = isfunctionhooked(func)

        if functionhook then
            game.Players.LocalPlayer:Destroy()
            return LPH_CRASH()
        end
    end
end

check_env( getgenv() )
check_env( getrenv() )
--

local Lua_Connections = getconnections
local Lua_Upvaules = getupvalues
local Lua_Hook = hookfunction 
local Lua_Hook_Method = hookmetamethod
local Lua_Unhook = restorefunction
local Lua_Replace_Function = replaceclosure
local Lua_Set_Upvalue = setupvalue
local Lua_Clone_Function = clonefunction

local Game_RunService = game:GetService("RunService")
local Game_LogService = game:GetService("LogService")
local Game_LogService_MessageOut = Game_LogService.MessageOut

local String_Lower = string.lower
local Table_Find = table.find
local Get_Type = type

local Current_Connections = {};
local Hooked_Connections = {};

local function Test_Table(Table, Return_Type)
for TABLE_INDEX, TABLE_VALUE in Table do
    if type(TABLE_VALUE) == String_Lower(Return_Type) then
        return TABLE_VALUE, TABLE_INDEX
    end

    continue
end
end

local function Print_Table(Table)
table.foreach(Table, print)
end

local good_check = 0

function heart()
return true , true
end

function Lua_Common_Intercept(old, ...)
print(...)
return old(...)
end

function XVNP_L(CONNECTION)
local s, e = pcall(function()
    local OPENAC_TABLE = Lua_Upvaules(CONNECTION.Function)[9]
    local OPENAC_FUNCTION = OPENAC_TABLE[1]
    local IGNORED_INDEX = {3, 12, 1, 11, 15, 8, 20, 18, 22}
    Lua_Set_Upvalue(OPENAC_FUNCTION, 14, function(...)
        return function(...)
            local args = {...}

            if type(args[1]) == "table" and args[1][1] then
                pcall(function()
                    if type(args[1][1]) == "userdata" then
                        args[1][1]:Disconnect()
                        args[1][2]:Disconnect()
                        args[1][3]:Disconnect()
                        args[1][4]:Disconnect()
                    end
                end)
            end 
        end
    end)

    Lua_Set_Upvalue(OPENAC_FUNCTION, 1, function(...)
        task.wait(200)
    end)

    hookfunction(OPENAC_FUNCTION, function(...)
        return {}
    end)
end)
end

local LastUpdate = 0
local UpdateInterval = 5

local ConnectionSniffer;

ConnectionSniffer = Game_RunService.RenderStepped:Connect(function()
if #Lua_Connections(Game_LogService_MessageOut) >= 2 then
    ConnectionSniffer:Disconnect()
end

if tick() - LastUpdate >= UpdateInterval then
    LastUpdate = tick() 

    local OpenAc_Connections = Lua_Connections(Game_LogService_MessageOut)

    for _, CONNECTION in OpenAc_Connections do
        if not table.find(Current_Connections, CONNECTION) then
            table.insert(Current_Connections, CONNECTION)
            table.insert(Hooked_Connections, CONNECTION)

            XVNP_L(CONNECTION)
            
        end
    end
end
end)

local last_beat = 0
Game_RunService.RenderStepped:Connect(function()
if last_beat + 1 < tick() then
    last_beat = tick() + 1 

    local what, are = heart()

    if not are or not what then
        if good_check <= 0 then
            game.Players.LocalPlayer:Destroy()
            return LPH_CRASH()
        else
            good_check -=1
        end
    else
        good_check += 1
    end

end
end)

if getgenv().OpenACTickler then
print("[PuppyWare.Final] PuppyWare Is Loading...")
end
task.wait(2)
game.Players.LocalPlayer.Character.Humanoid.Health = 0


local Script = {
    Targeting = { Target = nil },

    Functions = {},
    Connections = {},
    Drawings = {
        Lines = {},
        Labels = {
            Drawing.new('Text', {Size = 13, Font = 2, Outline = true, Text = 'PuppyWare', Color = Color3.new(1, 1, 1)}),
            Drawing.new('Text', {Size = 13, Font = 2, Outline = true, Text = ".Final"})
        }    
    },
    Utility = {
        Gun = {},
        SavedDesync = nil
    },
    Data = {
        Toggles = {
			Speed = false,
			Fly = false,
            ServerDesynchronization = false,
            BHop = false
        },
        LastPosition = nil,
    }
}


local StrafeCF = CFrame.new(0, 0, 0)

for i = 1, 8 do
    table.insert(Script.Drawings.Lines, Drawing.new('Line', {}))
end
--------------------------------------------------------------------- [[ Services ]] ---------------------------------------------------------------------
local Game = function(service) return game:GetService(service) end
local Players = Game("Players")
local Workspace = Game("Workspace")
local RunService = Game("RunService")
local UserInputService = Game("UserInputService")
local ReplicatedStorage = Game("ReplicatedStorage")
local TweenService = Game('TweenService')
--
local Client = Players.LocalPlayer
local Mouse = Client:GetMouse()
local Camera = Workspace.CurrentCamera
--
local Orginal = {}
local LastShotTime = 0
local UpdateTime = 0
local backpack = Client:WaitForChild("Backpack")
--
local Snapline = Drawing.new("Line"); Snapline.Thickness = PuppyWare.Visualization.On_Target.Snapline.Thickness; Snapline.Color = PuppyWare.Visualization.On_Target.Snapline.Color; Snapline.Transparency = PuppyWare.Visualization.On_Target.Snapline.Thickness
local TargetTracer = Drawing.new("Line"); TargetTracer.Thickness = PuppyWare.Visualization.On_Target.Tracer.Thickness; TargetTracer.Color = PuppyWare.Visualization.On_Target.Tracer.Color; TargetTracer.Transparency = 1
local Highlight = Instance.new("Highlight"); Highlight.Parent = gethui(); Highlight.FillColor = PuppyWare.Visualization.On_Target.Highlight.Color; Highlight.OutlineColor = PuppyWare.Visualization.On_Target.Highlight.Outline; Highlight.FillTransparency = 0.5
local FakeCharacter = game:GetObjects("rbxassetid://8246626421")[1]; FakeCharacter.Humanoid:Destroy(); FakeCharacter.Head.Face:Destroy(); FakeCharacter.Parent = Workspace; FakeCharacter.HumanoidRootPart.Velocity = Vector3.new(); FakeCharacter.HumanoidRootPart.CFrame = CFrame.new(9999,9999,9999); FakeCharacter.HumanoidRootPart.Transparency = 1; FakeCharacter.HumanoidRootPart.CanCollide = false for i,v in pairs(FakeCharacter:GetChildren()) do if v:IsA("BasePart") then v.CanCollide = false end end
local FakeCharacterHighlight = Instance.new("Highlight"); FakeCharacterHighlight.Parent = gethui(); FakeCharacterHighlight.Adornee = FakeCharacter; FakeCharacterHighlight.FillColor = Color3.fromRGB(173, 216, 230); FakeCharacterHighlight.OutlineColor = Color3.fromRGB(15, 64, 80); FakeCharacterHighlight.FillTransparency = 0.5

--------------------------------------------------------------------- [[ Drawings ]] ---------------------------------------------------------------------
do 
    do 
        Script.Functions.CreateConnection = function(Signal, Function)
            table.insert(Script.Connections, Signal:Connect(Function))
        end

        Script.Functions.CreateDrawing = function(Type, Properties)
            local NewDrawing = Drawing.new(Type)
            for i, v in next, Properties or {} do
                NewDrawing[i] = v
            end
            return NewDrawing
        end
        Script.Drawings.Fov = Script.Functions.CreateDrawing("Circle", {Visible = PuppyWare.Visualization.Fov.Properties.Visible, Radius = PuppyWare.Visualization.Fov.Properties.Radius, Thickness = 1, Transparency = PuppyWare.Visualization.Fov.Properties.Transparency, Color = PuppyWare.Visualization.Fov.Properties.Color})
    end
--------------------------------------------------------------------- [[ Functions ]] ---------------------------------------------------------------------
    do
        
        Script.Functions.WallCheck = function(part)
            local direction = (part.Position - Camera.CFrame.Position).Unit * (part.Position - Camera.CFrame.Position).Magnitude
            local ray = Ray.new(Camera.CFrame.Position, direction)
            local hit, pos = Workspace:FindPartOnRay(ray, Client.Character, false, true)
        
            if hit and hit:IsDescendantOf(part.Parent) and part.Parent:IsA("Model") then
                return false
            end
            return true
        end
        
        Script.Functions.Dead = function(Plr)
            local Dead = false
            if Plr and Plr.Character and PuppyWare.Combat.rage_bot.Misc.Checks.Un_Target.Dead and PuppyWare.Combat.rage_bot.Misc.Checks.Ignore.Dead then
                if Plr.Character:FindFirstChild("BodyEffects") then
                    if Plr.Character.BodyEffects:FindFirstChild("K.O") then
                        Dead = Plr.Character.BodyEffects["K.O"].Value
                    elseif Plr.Character.BodyEffects:FindFirstChild("KO") then
                        Dead = Plr.Character.BodyEffects.KO.Value
                    end
                end
            end
            return Dead
        end
    
        Script.Functions.Void = function(Player)
            if not Player or not Player.Character or not Player.Character:FindFirstChild("HumanoidRootPart") then
                return false
            end
        
            local YThreshold = -300
            return Player.Character.HumanoidRootPart.Position.Y < YThreshold
        end        
        
        Script.Functions.Validate = function(Player, Character)
            if PuppyWare.Combat.rage_bot.Misc.Checks.Un_Target.Not_Visible and not Script.Functions.WallCheck() then
                return false
            end
        
            if PuppyWare.Combat.rage_bot.Misc.Checks.Ignore.Not_Visible and not Script.Functions.WallCheck() then
                return false
            end
        
            if PuppyWare.Combat.rage_bot.Misc.Checks.Un_Target.Dead and Script.Functions.Dead(Player) then
                return false
            end
        
            if PuppyWare.Combat.rage_bot.Misc.Checks.Ignore.Dead and Script.Functions.Dead(Player) then
                return false
            end
        
            if PuppyWare.Combat.rage_bot.Misc.Checks.Ignore.Void and Script.Functions.Void(Player) then
                return false
            end
        
            return true
        end

        Script.Functions.GetClosestPlayer = function()
            local ClosestPlayer = nil
            local ClosestDistance = math.huge
            for _, Player in ipairs(Players:GetPlayers()) do
                if Player ~= Client and Player.Character and Player.Character:FindFirstChild("HumanoidRootPart") then
                    if Player.Character:FindFirstChild("HumanoidRootPart") then
                        local ScreenPosition, OnScreen = Camera:WorldToViewportPoint(Player.Character:FindFirstChild("HumanoidRootPart").Position)
                        if not OnScreen or not Script.Functions.Validate() then continue end
                        if OnScreen then
                            local MousePosition = Vector2.new(Mouse.X, Mouse.Y)
                            local Distance = (Vector2.new(ScreenPosition.X, ScreenPosition.Y) - MousePosition).Magnitude
    
                            if Distance < ClosestDistance and Distance <= Script.Drawings.Fov.Radius then
                                ClosestDistance = Distance
                                ClosestPlayer = Player
                            end
                        end
                    end
                end
            end
            return ClosestPlayer
        end

        Script.Functions.ShootRemote = function(tool, enemy)
            if enemy and enemy.Character and enemy.Character:FindFirstChild("Head") then
                local shootPosition = tool:FindFirstChild("Handle") and tool:FindFirstChild("Handle").CFrame.Position or Client.Character.Head.Position
                
                if Script.Data.Toggles.ServerDesynchronization and PuppyWare.HvH.Antis.ServerDesynchronization and StrafeCF then
                    shootPosition = StrafeCF.Position
                end
                
                ReplicatedStorage.MainEvent:FireServer(
                    "ShootGun",
                    tool:FindFirstChild("Handle"),
                    shootPosition, 
                    enemy.Character.HumanoidRootPart.Position,
                    enemy.Character.Head,
                    Vector3.new(0, 0, -1)
                )
            end
        end

        Script.Functions.KillAura = function()
            local ClosestPlayer = Script.Functions.GetClosestPlayer()
            local tool = Client.Character and Client.Character:FindFirstChildOfClass("Tool")
            if ClosestPlayer and tool then
                Script.Functions.ShootRemote(tool, ClosestPlayer)
            end
        end
    end

    Script.Functions.CFrameToOffset = function(Origin, Target)
        local ActualOrigin = Origin * CFrame.new(0, -1, 0, 1, 0, 0, 0, 0, 1, 0, -1, 0)
        return ActualOrigin:ToObjectSpace(Target):inverse()
    end

    Script.Functions.TeleportBullet = function(Tool)
        local Target = Script.Targeting.Target
        if not (Target and Target.Character and Target.Character:FindFirstChild("HumanoidRootPart")) then return end
    
        local OriginPart = Client.Character and Client.Character:FindFirstChild("HumanoidRootPart")
        local TargetPart = Target.Character.HumanoidRootPart
    
        if OriginPart and TargetPart then
            local OriginalGrip = Tool.Grip
            Tool.Parent = Client.Backpack
            Tool.Grip = Script.Functions.CFrameToOffset(Client.Character.RightHand.CFrame, TargetPart.CFrame)
            Tool.Parent = Client.Character
            RunService.RenderStepped:Wait()
            Tool.Parent = Client.Backpack
            Tool.Grip = OriginalGrip
            Tool.Parent = Client.Character
        end
    end
    
    Script.Functions.HandleCharacter = function(Character)
        for _, Conn in ipairs({ "CharacterChildAdded", "ChildRemovingCharacter" }) do
            if Script.Connections[Conn] then
                Script.Connections[Conn]:Disconnect()
            end
        end
    
        Script.Connections.CharacterChildAdded = Character.ChildAdded:Connect(function(Tool)
            if Tool:IsA("Tool") then
                for _, Conn in ipairs(getconnections(Tool:GetPropertyChangedSignal("Grip"))) do
                    Conn:Disable()
                end
    
                Script.Connections.ToolActivated = Tool.Activated:Connect(function()
                    if PuppyWare.Combat.rage_bot.Rage.Bullet_Manipulation then
                        Script.Functions.TeleportBullet(Tool)
                    end
                end)
            end
        end)
    
        Script.Connections.ChildRemovingCharacter = Character.ChildRemoved:Connect(function()
            Script.Utility.Gun.Tool = nil
            if Script.Connections.ToolActivated then
                Script.Connections.ToolActivated:Disconnect()
            end
        end)
    end

    Script.Functions.CrosshairPos = function(angle, radius)
        return Vector2.new(
            math.sin(math.rad(angle)) * radius,
            math.cos(math.rad(angle)) * radius
        )
    end   

    Script.Functions.KeepInv = function()
        if  PuppyWare.Combat.rage_bot.Rage.KeepInv and Client and Client:FindFirstChildOfClass("Humanoid") then
            Client:FindFirstChildOfClass("Humanoid").Health = 0
        end
    end

    Script.Functions.AutoStomp = function()
        if PuppyWare.Combat.rage_bot.Rage.Auto_Stomp then
            local character = Client.Character
            local target = Script.Targeting.Target
    
            if character and character:FindFirstChild("HumanoidRootPart") and target and target:FindFirstChild("LowerTorso") then
                if Script.Functions.Dead(target) then
                    local hrp = character.HumanoidRootPart
                    local originalCFrame = hrp.CFrame
                    local TargetPos = target.LowerTorso.Position
    
                    hrp.CFrame = CFrame.new(TargetPos + Vector3.new(0, 1.5, 0))
                    ReplicatedStorage.MainEvent:FireServer("Stomp")
    
                    task.delay(0, function()
                        if character and character:FindFirstChild("HumanoidRootPart") then
                            character.HumanoidRootPart.CFrame = originalCFrame
                        end
                    end)
                end
            end
        end
    end
        
    Script.Functions.MultiEquip = function()
        local client = game.Players.LocalPlayer
        for _, tool in next, client.Backpack:GetChildren() do
            if tool:IsA("Tool") and tool:FindFirstChild("Ammo") then
                tool.Parent = client.Character
            end
        end
    end
    
    Script.Functions.autoStompNearbyPlayers = function()
        if _G.AutoStompConnection then
            _G.AutoStompConnection:Disconnect()
        end
        
        _G.AutoStompConnection = RunService.Heartbeat:Connect(function()
            if not PuppyWare.Combat.rage_bot.Rage.Auto_Stomp then
                _G.AutoStompConnection:Disconnect()
                _G.AutoStompConnection = nil
                return
            end
            
            local targetPlayer = Script.Targeting.Target
            if not targetPlayer then return end
            
            local playerCharacter = Client.Character
            if not playerCharacter or not playerCharacter:FindFirstChild("HumanoidRootPart") then return end
            
            local character = targetPlayer.Character
            if not character then return end
            
            local bodyEffects = character:FindFirstChild("BodyEffects")
            local isKO = bodyEffects and bodyEffects:FindFirstChild("K.O") and bodyEffects["K.O"].Value
            local isSDeath = bodyEffects and bodyEffects:FindFirstChild("SDeath") and bodyEffects["SDeath"].Value
            
            if isKO and not isSDeath then
                local upperTorso = character:FindFirstChild("UpperTorso")
                if upperTorso then
                    local humanoidRootPart = playerCharacter:FindFirstChild("HumanoidRootPart")
                    if humanoidRootPart then
                        local originalPosition = humanoidRootPart.CFrame
                        local originalFakePosition = nil
                        
                        if Script.Data.Toggles.ServerDesynchronization and PuppyWare.HvH.Antis.ServerDesynchronization then
                            Script.Data.Toggles.ServerDesynchronization = false
                            
                            originalFakePosition = FakeCharacter.HumanoidRootPart.CFrame
                            FakeCharacter:SetPrimaryPartCFrame(CFrame.new(upperTorso.Position + Vector3.new(0, 3, 0)))
                            RunService.RenderStepped:Wait()
                            ReplicatedStorage.MainEvent:FireServer("Stomp")
                            RunService.RenderStepped:Wait()
                            
                            if originalFakePosition then
                                FakeCharacter:SetPrimaryPartCFrame(originalFakePosition)
                            end
                            
                            Script.Data.Toggles.ServerDesynchronization = Script.Data.Toggles.ServerDesynchronization
                        end
                    end
                end
            end
        end)
    end
    

    Script.Functions.startAntiStomp = function()
        if _G.AntiStompConnection then
            _G.AntiStompConnection:Disconnect()
        end
        
        _G.AntiStompConnection = RunService.Heartbeat:Connect(function()
            if not PuppyWare.Combat.rage_bot.Rage.Anti_Stomp then
                _G.AntiStompConnection:Disconnect()
                _G.AntiStompConnection = nil
                return
            end
            
            local chr = Client.Character
            if not chr then return end
            
            local bodyEffects = chr:FindFirstChild("BodyEffects")
            if not bodyEffects then return end
            
            local koValue = bodyEffects:FindFirstChild("K.O")
            if not koValue or not koValue.Value then return end
            
            if koValue.Value == true then
                if PuppyWare.Combat.rage_bot.Rage.Flashback then
                    Script.Data.LastPosition = chr:GetPrimaryPartCFrame()
                end
                
                local humanoid = chr:FindFirstChildOfClass("Humanoid")
                if humanoid and humanoid.Health > 0 then
                    humanoid.Health = 0
                end
            end
        end)
        
        Client.CharacterAdded:Connect(function(newCharacter)
            if PuppyWare.Combat.rage_bot.Rage.Anti_Stomp and PuppyWare.Combat.rage_bot.Rage.Flashback and Script.Data.LastPosition then
                local rootPart = newCharacter:WaitForChild("HumanoidRootPart", 5)
                if rootPart then
                    rootPart.CFrame = Script.Data.LastPosition
                    Script.Data.LastPosition = nil
                end
            end
        end)
    end

    -- Add notification function
    Script.Functions.SetRenderProperty = function(instance, property, value)
        if instance then
            instance[property] = value
        end
    end

    -- Add target locked notification and tracer
    Script.Functions.CreateConnection(RunService.RenderStepped, function() -- // Target Lock Notification \\ --
        local CurrentTarget = Script.Targeting.Target
        
        if CurrentTarget and CurrentTarget ~= Script.Targeting.LastTarget and PuppyWare.Visualization.On_Target.Notifications.Enabled then
            -- Display notification when target is locked on
            Script.Functions.SetRenderProperty(Highlight, "Adornee", CurrentTarget.Character)
            Script.Functions.SetRenderProperty(TargetTracer, "To", CurrentTarget.Character.HumanoidRootPart.Position)
            Script.Functions.SetRenderProperty(TargetTracer, "Visible", true)
            Script.Functions.SetRenderProperty(TargetTracer, "From", CurrentTarget.Character.HumanoidRootPart.Position)
        elseif not CurrentTarget then
            Script.Targeting.LastTarget = nil
        end
        
        -- Update tracer for locked target
        if CurrentTarget and CurrentTarget.Character and CurrentTarget.Character:FindFirstChild("HumanoidRootPart") then
            local RootPart = CurrentTarget.Character.HumanoidRootPart
            local ClientRootPart = Client.Character and Client.Character:FindFirstChild("HumanoidRootPart")
            
            if ClientRootPart and PuppyWare.Visualization.On_Target.Tracer.Enabled then
                local ClientPos, ClientOnScreen = Camera:WorldToViewportPoint(ClientRootPart.Position)
                local TargetPos, TargetOnScreen = Camera:WorldToViewportPoint(RootPart.Position)
                
                if ClientOnScreen and TargetOnScreen then
                    Script.Functions.SetRenderProperty(TargetTracer, "Visible", true)
                    Script.Functions.SetRenderProperty(TargetTracer, "From", Vector2.new(ClientPos.X, ClientPos.Y))
                    Script.Functions.SetRenderProperty(TargetTracer, "To", Vector2.new(TargetPos.X, TargetPos.Y))
                else
                    Script.Functions.SetRenderProperty(TargetTracer, "Visible", false)
                end
            else
                Script.Functions.SetRenderProperty(TargetTracer, "Visible", false)
            end
        else
            Script.Functions.SetRenderProperty(TargetTracer, "Visible", false)
        end
    end)
end
--------------------------------------------------------------------- [[ Inputs ]] ---------------------------------------------------------------------
do ----[[ Input ]]----
    Script.Functions.CreateConnection(UserInputService.InputBegan, function(Input, gameProccessedEvent)
        if gameProccessedEvent then return end
    
        local key = Input.KeyCode.Name:lower() 
        
        if key == PuppyWare.Combat.rage_bot.Keybind:lower() then
            Script.Targeting.Target = Script.Functions.GetClosestPlayer()
        elseif key == PuppyWare.HvH.Antis.Key:lower() then
            Script.Data.Toggles.ServerDesynchronization = not Script.Data.Toggles.ServerDesynchronization
        elseif key == PuppyWare.Misc.player.FlyKey:lower() and PuppyWare.Misc.player.FlyEnabled then
            Script.Data.Toggles.Fly = not Script.Data.Toggles.Fly
        elseif key == PuppyWare.Misc.player.SpeedKey:lower() and PuppyWare.Misc.player.SpeedEnabled then
            Script.Data.Toggles.Speed = not Script.Data.Toggles.Speed
        elseif key == PuppyWare.Combat.rage_bot.Rage.All_Guns_Key:lower() and PuppyWare.Combat.rage_bot.Rage.All_Guns then
            Script.Functions.MultiEquip()
        end

        if PuppyWare.Combat.rage_bot.Rage.Anti_Stomp then
            Script.Functions.startAntiStomp()
        end
        
        if PuppyWare.Combat.rage_bot.Rage.Auto_Reload then
            Script.Functions.startAutoReload()
        end
        
        if PuppyWare.Combat.rage_bot.Rage.Auto_Stomp then
            Script.Functions.autoStompNearbyPlayers()
        end
    end)
end
--------------------------------------------------------------------- [[ FrameWork ]] ---------------------------------------------------------------------
Script.Functions.CreateConnection(RunService.RenderStepped, function() -- // Silent Aim \\ --
    local MousePos = UserInputService:GetMouseLocation()
    Script.Drawings.Fov.Position = Vector2.new(MousePos.X, MousePos.Y)

    local target = Script.Targeting.Target
    if target and (not target.Character or not target.Character:FindFirstChild("HumanoidRootPart")) then
        Script.Targeting.Target = nil
    end

    if PuppyWare.Combat.rage_bot.Misc.Auto_Select and not Script.Targeting.Target then
        Script.Targeting.Target = Script.Functions.GetClosestPlayer()
    end
end)

Script.Functions.CreateConnection(RunService.RenderStepped, function(Delta) --// Rage bot \\--
    if PuppyWare.Combat.rage_bot.Misc.Auto_Select and PuppyWare.Combat.rage_bot.Enabled then
        Script.Targeting.Target = Script.Functions.GetClosestPlayer(Script.Drawings.Fov.Radius)
    end
end)


Script.Functions.CreateConnection(RunService.RenderStepped, function() -- // Rapid Fire \\ --
    local tool = Client.Character and Client.Character:FindFirstChildOfClass("Tool")
    if tool and tool:FindFirstChild("GunScript") then
        for _, connection in ipairs(getconnections(tool.Activated)) do
            local func = connection.Function
            if func then
                local funcInfo = debug.getinfo(func)
                for i = 1, funcInfo.nups do
                    local upvalue, name = debug.getupvalue(func, i)
                    if type(upvalue) == "number" then
                        if not Orginal[i] then
                            Orginal[i] = upvalue
                        end
                        debug.setupvalue(func, i, PuppyWare.Combat.rage_bot.Rage.Fire_rate or Orginal[i])
                    end
                end
            end
        end
    end
end)

Script.Functions.CreateConnection(RunService.Heartbeat, function(Delta) -- // Kill Aura \\ --
    if PuppyWare.Combat.rage_bot.Rage.Kill_Aura then
        Script.Functions.KillAura()
    end
end)

Script.Functions.CreateConnection(RunService.RenderStepped, function() -- // Kill Aura \\ --
    if PuppyWare.Combat.rage_bot.Rage.Auto_Shoot then
        local CurrentTime = tick()
        if CurrentTime - LastShotTime < 0.00001 then return end

        local tool = Client.Character and Client.Character:FindFirstChildOfClass("Tool")
        local target = Script.Targeting.Target

        if tool and target and target.Character and target.Character:FindFirstChild(PuppyWare.Combat.rage_bot.Hit_part) then
            Script.Functions.ShootRemote(tool, target)
            LastShotTime = CurrentTime
        end
    end
end)

Script.Functions.CreateConnection(RunService.Heartbeat, function(Delta) --// Target Visuals \\--
    if Script.Targeting.Target and Script.Targeting.Target.Character then
        if PuppyWare.Visualization.On_Target.Highlight.Enabled then
            Script.Functions.SetRenderProperty(Highlight, "Adornee", Script.Targeting.Target.Character)
        else
            Script.Functions.SetRenderProperty(Highlight, "Adornee", nil)
        end
    else
        Script.Functions.SetRenderProperty(Highlight, "Adornee", nil)
    end
end)

Script.Functions.CreateConnection(RunService.Heartbeat, function(Delta)
    local Target = Script.Targeting.Target
    if Target and Target.Character and Target.Character:FindFirstChild("HumanoidRootPart") then
        if PuppyWare.Visualization.On_Target.Snapline.Enabled then
            local RootPart = Target.Character.HumanoidRootPart
            local MousePos = UserInputService:GetMouseLocation()
            local ScreenPos, OnScreen = Camera:WorldToViewportPoint(RootPart.Position)

            if OnScreen then
                if PuppyWare.Combat.rage_bot.Misc.Auto_Select then
                    if (Vector2.new(ScreenPos.X, ScreenPos.Y) - Vector2.new(MousePos.X, MousePos.Y)).Magnitude <= Script.Drawings.Fov.Radius then
                        Script.Functions.SetRenderProperty(Snapline, "Visible", true)
                        Script.Functions.SetRenderProperty(Snapline, "From", Vector2.new(MousePos.X, MousePos.Y))
                        Script.Functions.SetRenderProperty(Snapline, "To", Vector2.new(ScreenPos.X, ScreenPos.Y))
                    else
                        Script.Functions.SetRenderProperty(Snapline, "Visible", false)
                    end
                else
                    Script.Functions.SetRenderProperty(Snapline, "Visible", true)
                    Script.Functions.SetRenderProperty(Snapline, "From", Vector2.new(MousePos.X, MousePos.Y))
                    Script.Functions.SetRenderProperty(Snapline, "To", Vector2.new(ScreenPos.X, ScreenPos.Y))
                end
            else
                Script.Functions.SetRenderProperty(Snapline, "Visible", false)
            end
        else
            Script.Functions.SetRenderProperty(Snapline, "Visible", false)
        end
    else
        Script.Functions.SetRenderProperty(Snapline, "Visible", false)
    end
end)


Script.Functions.CreateConnection(RunService.RenderStepped, function() -- // Crosshair \\ --
    local CurrentTime = tick()

    if CurrentTime - UpdateTime > 0 then
        UpdateTime = CurrentTime

        local CrosshairPosition = (
            PuppyWare.Visualization.Crosshair.Global.Orgin == 'Center' and Camera.ViewportSize / 2 or
            PuppyWare.Visualization.Crosshair.Global.Orgin == 'Mouse' and UserInputService:GetMouseLocation() or
            PuppyWare.Visualization.Crosshair.Global.Pos
        )

        local TextWidth = Script.Drawings.Labels[1].TextBounds.X + Script.Drawings.Labels[2].TextBounds.X

        Script.Drawings.Labels[1].Visible = PuppyWare.Visualization.Crosshair.Global.Enabled
        Script.Drawings.Labels[2].Visible = PuppyWare.Visualization.Crosshair.Global.Enabled

        if PuppyWare.Visualization.Crosshair.Global.Enabled then
            Script.Drawings.Labels[1].Position = CrosshairPosition + Vector2.new(-TextWidth / 2, PuppyWare.Visualization.Crosshair.Settings.Radius + PuppyWare.Visualization.Crosshair.Settings.Length + 15)
            Script.Drawings.Labels[2].Position = Script.Drawings.Labels[1].Position + Vector2.new(Script.Drawings.Labels[1].TextBounds.X)
            Script.Drawings.Labels[2].Color = PuppyWare.Visualization.Crosshair.Settings.Color

            for i = 1, 4 do
                local OutlineLine = Script.Drawings.Lines[i]
                local InnerLine = Script.Drawings.Lines[i + 4]

                local angle = (i - 1) * 90
                local length = PuppyWare.Visualization.Crosshair.Settings.Length

                if PuppyWare.Visualization.Crosshair.Effects.Spin then
                    local rotationValue = -CurrentTime * PuppyWare.Visualization.Crosshair.Effects.Speed % PuppyWare.Visualization.Crosshair.Effects.Angle
                    angle = angle + TweenService:GetValue(rotationValue / 360, PuppyWare.Visualization.Crosshair.Effects.Curve, Enum.EasingDirection.InOut) * 360
                end

                if PuppyWare.Visualization.Crosshair.Animate.Enabled then
                    local animationValue = math.sin(CurrentTime * PuppyWare.Visualization.Crosshair.Animate.Speed) * (PuppyWare.Visualization.Crosshair.Animate.MaxSize - PuppyWare.Visualization.Crosshair.Animate.MinSize) + PuppyWare.Visualization.Crosshair.Animate.MinSize
                    length = length + animationValue
                end

                InnerLine.Visible = true
                InnerLine.Color = PuppyWare.Visualization.Crosshair.Settings.Color
                InnerLine.From = CrosshairPosition + Script.Functions.CrosshairPos(angle, PuppyWare.Visualization.Crosshair.Settings.Radius)
                InnerLine.To = CrosshairPosition + Script.Functions.CrosshairPos(angle, PuppyWare.Visualization.Crosshair.Settings.Radius + length)
                InnerLine.Thickness = PuppyWare.Visualization.Crosshair.Settings.Width

                OutlineLine.Visible = true
                OutlineLine.From = CrosshairPosition + Script.Functions.CrosshairPos(angle, PuppyWare.Visualization.Crosshair.Settings.Radius - 1)
                OutlineLine.To = CrosshairPosition + Script.Functions.CrosshairPos(angle, PuppyWare.Visualization.Crosshair.Settings.Radius + length + 1)
                OutlineLine.Thickness = PuppyWare.Visualization.Crosshair.Settings.Width + 1.5
            end
        else
            for i = 1, 8 do
                Script.Drawings.Lines[i].Visible = false
            end
        end
    end
end)


Script.Functions.CreateConnection(RunService.Heartbeat, function(Delta) --// CSync \\--
    if Client.Character and Script.Data.Toggles.ServerDesynchronization and PuppyWare.HvH.Antis.ServerDesynchronization then
        if not Script.Targeting.Target then
            local Strafes = {
                ['Random'] = CFrame.new(Client.Character.HumanoidRootPart.Position - Vector3.new(math.random(-10, 10), 0, math.random(-10, 10))),
                ['Void'] = CFrame.new(math.random(-44444, 44444), math.random(-44444, 44444), math.random(-44444, 44444)),
            }
            
            StrafeCF = Strafes[PuppyWare.HvH.Antis.Modes]
            Script.Utility.SavedDesync = Client.Character.HumanoidRootPart.CFrame
            Client.Character.HumanoidRootPart.CFrame = StrafeCF
            FakeCharacter:SetPrimaryPartCFrame(Client.Character.HumanoidRootPart.CFrame)
            RunService.RenderStepped:Wait()
            Client.Character.HumanoidRootPart.CFrame = Script.Utility.SavedDesync
		else 
            local Strafes = {
                ['Random'] = CFrame.new(Script.Targeting.Target.Character.HumanoidRootPart.Position - Vector3.new(math.random(-10, 10), 0, math.random(-10, 10))),
                ['Void'] = CFrame.new(math.random(-44444, 44444), math.random(-44444, 44444), math.random(-44444, 44444))
            }
            StrafeCF = Strafes[PuppyWare.HvH.Antis.Modes]
            Script.Utility.SavedDesync = Client.Character.HumanoidRootPart.CFrame
            Client.Character.HumanoidRootPart.CFrame = StrafeCF
            FakeCharacter:SetPrimaryPartCFrame(Client.Character.HumanoidRootPart.CFrame)
            RunService.RenderStepped:Wait()
            Client.Character.HumanoidRootPart.CFrame = Script.Utility.SavedDesync
		end
    else
        FakeCharacter:SetPrimaryPartCFrame(CFrame.new(99999, 99999, 999999))
    end

    if (Script.Data.Toggles.Speed) and (Client and Client.Character) then
        Client.Character.HumanoidRootPart.CFrame = Client.Character.HumanoidRootPart.CFrame + Client.Character:WaitForChild("Humanoid").MoveDirection * PuppyWare.Misc.player.Speed
    end

	if (Script.Data.Toggles.Fly) and (Client and Client.Character and Client.Character:FindFirstChild("HumanoidRootPart")) then
		local RootPart = Client.Character.HumanoidRootPart
		local MoveDirection = Vector3.zero
		
		if UserInputService:IsKeyDown(Enum.KeyCode.W) then MoveDirection = MoveDirection + Camera.CFrame.LookVector end
		if UserInputService:IsKeyDown(Enum.KeyCode.S) then MoveDirection = MoveDirection - Camera.CFrame.LookVector end
		if UserInputService:IsKeyDown(Enum.KeyCode.A) then MoveDirection = MoveDirection - Camera.CFrame.RightVector end
		if UserInputService:IsKeyDown(Enum.KeyCode.D) then MoveDirection = MoveDirection + Camera.CFrame.RightVector end
		
		if MoveDirection.Magnitude > 0 then
			MoveDirection = MoveDirection.Unit * PuppyWare.Misc.player.FlySpeed
		end
		
		RootPart.Velocity = MoveDirection
	end
end)

Client.CharacterAdded:Wait():WaitForChild("Humanoid").StateChanged:Connect(function(_, NewState)
	if not Script.Data.Toggles.BHop then return end
    if PuppyWare.Combat.rage_bot.Misc.BunnyHop then 
        if NewState == Enum.HumanoidStateType.Landed then
            task.wait() 
            Client.CharacterAdded:Wait():WaitForChild("Humanoid"):ChangeState(Enum.HumanoidStateType.Jumping)
        end
    end
end)

---------------[[ Bullet Tp ]]---------------
local function SetupCharacter(Char)
    Script.Functions.HandleCharacter(Char)
end

local CurrentCharacter = Client.Character or Client.CharacterAdded:Wait()
SetupCharacter(CurrentCharacter)

Client.CharacterAdded:Connect(SetupCharacter)

Client.CharacterRemoving:Connect(function()
    for _, Conn in ipairs({ "CharacterChildAdded", "ChildRemovingCharacter" }) do
        if Script.Connections[Conn] then
            Script.Connections[Conn]:Disconnect()
        end
    end
end)
-------------------------------------------------------------- [[ Hooks ]] ---------------------------------------------------------------------
local grm = getrawmetatable(game)  -- // Silent Aim \\ --
local index = grm.__index
setreadonly(grm, false)

grm.__index = function(self, Index)
    if not checkcaller() and self == Mouse and PuppyWare.Combat.rage_bot.Enabled then
        if (Index == "Hit" or Index == "Target") then
            local target = Script.Targeting.Target
            if target and target.Character and target.Character:FindFirstChild(PuppyWare.Combat.rage_bot.Hit_part) then
                local part = target.Character[PuppyWare.Combat.rage_bot.Hit_part]
                return CFrame.new(part.Position + (part.Velocity * PuppyWare.Combat.rage_bot.Prediction))
            end
        end
    end
    return index(self, Index)
end

local newindex; newindex = hookmetamethod(game, "__newindex", function(self, Index, Value)
    if not checkcaller() and PuppyWare.Combat.rage_bot.Misc.NoJumpCoolDown then
        if self:IsA("Humanoid") and Index == "JumpPower" then 
            return
        end
    end

    return newindex(self, Index, Value)
end)


local mt = getrawmetatable(game)
local backup; backup = hookfunction(mt.__newindex, newcclosure(function(self, key, value)
    if not checkcaller() and Table and Table.Misc and PuppyWare.Combat.rage_bot.Misc.NoSlowDown then
        if self:IsA("Humanoid") and key == "WalkSpeed" and value < 25 then
            value = 25
        end
    end
    return backup(self, key, value)
end))

local CSyncIndex; CSyncIndex = hookmetamethod(game, "__index", function(Self, Index)  -- // Csync \\ --
    if not checkcaller() and Script.Data.Toggles.ServerDesynchronization and PuppyWare.HvH.Antis.ServerDesynchronization and Script.Utility.SavedDesync and Index == "CFrame" and Self == Client.Character.HumanoidRootPart then
        return Script.Utility.SavedDesync
    end
    return CSyncIndex(Self, Index)
end)

local OriginalCall; OriginalCall = hookmetamethod(game, "__namecall", function(Object, ...) -- // WallBang \\ --
    if not Script.Targeting.Target or not Script.Targeting.Target.Character or not Script.Targeting.Target.Character[PuppyWare.Combat.rage_bot.Hit_part] then
        return OriginalCall(Object, ...)
    end

    local Arguments = {...}
    local Method = tostring(getnamecallmethod())
    local CallingScript = getcallingscript()

    if Method == "Raycast" and Object.Name == "Workspace" and CallingScript.Name ~= "Bike" then
        if PuppyWare.Combat.rage_bot.Rage.Wallbang then
            Arguments[3] = RaycastParams.new()
            Arguments[3].FilterDescendantsInstances = {
                Script.Targeting.Target.Character,
                Script.Targeting.Target.Character[PuppyWare.Combat.rage_bot.Hit_part]
            }
            Arguments[3].FilterType = Enum.RaycastFilterType.Include
            Arguments[3].IgnoreWater = true
        end

        return OriginalCall(Object, unpack(Arguments))
    end

    return OriginalCall(Object, ...)
end)

--------------------------------------------------------------------- [[ ESP Implementation ]] ---------------------------------------------------------------------

do
    local environment = setmetatable({}, { __index = function(_, index)
        local v = index:gsub("_%l", string.upper):gsub("_", ""):gsub("^%l", string.upper);
        return cloneref(game:GetService(v));
    end});

    local Esp = PuppyWare.Visuals.player_esp
    local vertices = { { -0.5, -0.5, -0.5 }, { -0.5, 0.5, -0.5 }, { 0.5, -0.5, -0.5 }, { 0.5, 0.5, -0.5 },{ -0.5, -0.5, 0.5 }, { -0.5, 0.5, 0.5 }, { 0.5, -0.5, 0.5 }, { 0.5, 0.5, 0.5 } };
    
    local espObjects = {}
    
    local createEspObjects = LPH_NO_VIRTUALIZE(function(player)
        if espObjects[player] then return espObjects[player] end
        
        local objects = {
            Name = Drawing.new("Text"),
            Distance = Drawing.new("Text"),
            Weapon = Drawing.new("Text"),
            BoxOutline = Drawing.new("Square"),
            Box = Drawing.new("Square"),
            HealthBarOutline = Drawing.new("Square"),
            HealthBar = Drawing.new("Square"),
            HealthText = Drawing.new("Text"),
            Arrow = Drawing.new("Triangle"),
        }
        
        objects.Name.Size = 13
        objects.Name.Center = true
        objects.Name.Outline = true
        objects.Name.Font = 2
        objects.Name.Color = Esp.Accent
        
        objects.Distance.Size = 13
        objects.Distance.Center = true
        objects.Distance.Outline = true
        objects.Distance.Font = 2
        objects.Distance.Color = Esp.Distance_Accent
        
        objects.Weapon.Size = 13
        objects.Weapon.Center = true
        objects.Weapon.Outline = true
        objects.Weapon.Font = 2
        objects.Weapon.Color = Esp.Weapon_Accent
        
        objects.BoxOutline.Thickness = 3
        objects.BoxOutline.Filled = false
        objects.BoxOutline.Color = Color3.new(0, 0, 0)
        
        objects.Box.Thickness = 1
        objects.Box.Filled = false
        objects.Box.Color = Esp.Box_Accent
        
        objects.HealthBarOutline.Thickness = 3
        objects.HealthBarOutline.Filled = false
        objects.HealthBarOutline.Color = Color3.new(0, 0, 0)
        
        objects.HealthBar.Thickness = 1
        objects.HealthBar.Filled = true
        
        objects.HealthText.Size = 13
        objects.HealthText.Center = true
        objects.HealthText.Outline = true
        objects.HealthText.Font = 2
        objects.HealthText.Color = Color3.new(1, 1, 1)
        
        objects.Arrow.Thickness = 1
        objects.Arrow.Filled = true
        objects.Arrow.Visible = false
        objects.Arrow.Color = Esp.Arrows_Accent
        
        espObjects[player] = objects
        return objects
    end)
    
    local removeEspObjects = LPH_NO_VIRTUALIZE(function(player)
        local objects = espObjects[player]
        if not objects then return end
        
        for _, object in pairs(objects) do
            pcall(function() object:Remove() end)
        end
        
        espObjects[player] = nil
    end)
    
    Script.Functions.custom_bounds = LPH_NO_VIRTUALIZE(function(model)
        local min_bound, max_bound = Vector3.new(math.huge, math.huge, math.huge), Vector3.new(-math.huge, -math.huge, -math.huge)
        local min_width = 2.5;
    
        for _, part in model:GetChildren() do
            if part:IsA("BasePart") then
                local cframe, size = part.CFrame, part.Size
                for _, v in vertices do
                    local world_space = cframe:PointToWorldSpace(Vector3.new(v[1] * size.X, (v[2] + 0.2) * (size.Y + 0.2), v[3] * size.Z))
                    min_bound = Vector3.new(math.min(min_bound.X, world_space.X), math.min(min_bound.Y, world_space.Y), math.min(min_bound.Z, world_space.Z))
                    max_bound = Vector3.new(math.max(max_bound.X, world_space.X), math.max(max_bound.Y, world_space.Y), math.max(max_bound.Z, world_space.Z))
                end
            end
        end
    
        if min_bound == Vector3.new(math.huge, math.huge, math.huge) then return end
    
        local size = max_bound - min_bound
        size = Vector3.new(math.max(size.X, min_width), size.Y, size.Z)
    
        local center = (min_bound + max_bound) / 2
        return CFrame.new(center), size, center
    end)
    
    Script.Functions.get_tool_name = LPH_NO_VIRTUALIZE(function(character)    
        for _, v in character:GetChildren() do
            if not v:IsA('Model') then
                continue
            end
    
            if v.Name == 'Hair' or v.Name == 'HolsterModel' then
                continue
            end
    
            if not v.PrimaryPart then
                continue
            end
    
            if v:FindFirstChild("Detail") or v:FindFirstChild("Main") or v:FindFirstChild("Handle") or v:FindFirstChild("Attachments") or v:FindFirstChild("ArrowAttach") or v:FindFirstChild("Attach") then
                return v.Name;
            end;
        end;
        return "none";
    end)
    
    local updatePlayerESP = LPH_NO_VIRTUALIZE(function()
        if not Esp.Enabled then
            for player, _ in pairs(espObjects) do
                removeEspObjects(player)
            end
            return
        end
        
        for _, player in pairs(Players:GetPlayers()) do
            if player == Client then continue end
            
            local character = player.Character
            if not character or not character:FindFirstChild("HumanoidRootPart") or not character:FindFirstChild("Humanoid") then
                if espObjects[player] then
                    for _, obj in pairs(espObjects[player]) do
                        obj.Visible = false
                    end
                end
                continue
            end
            
            local humanoid = character:FindFirstChildOfClass("Humanoid")
            if not humanoid then continue end
            
            if Esp.Teamcheck and player.Team == Client.Team then
                if espObjects[player] then
                    for _, obj in pairs(espObjects[player]) do
                        obj.Visible = false
                    end
                end
                continue
            end
            
            local rootPart = character:FindFirstChild("HumanoidRootPart")
            local distance = (rootPart.Position - Camera.CFrame.Position).Magnitude
            if distance > Esp.Distance_Check then
                if espObjects[player] then
                    for _, obj in pairs(espObjects[player]) do
                        obj.Visible = false
                    end
                end
                continue
            end
            
            local esp = createEspObjects(player)
            
            local cf, size, center = Script.Functions.custom_bounds(character)
            if not cf then
                for _, obj in pairs(esp) do
                    obj.Visible = false
                end
                continue
            end
            
            local position, visible = Camera:WorldToViewportPoint(center)
            if not visible then
                if Esp.Arrows then
                    local screenCenter = Camera.ViewportSize / 2
                    local directionVector = (Vector2.new(position.X, position.Y) - screenCenter).Unit
                    local arrowPosition = screenCenter + directionVector * Esp.Radius
                    
                    local arrowSize = Esp.Size
                    local points = {}
                    if Esp.Points == "Three" then
                        points = {
                            Vector2.new(arrowPosition.X, arrowPosition.Y),
                            Vector2.new(arrowPosition.X - arrowSize, arrowPosition.Y + arrowSize),
                            Vector2.new(arrowPosition.X + arrowSize, arrowPosition.Y + arrowSize)
                        }
                    else
                        local angle = math.atan2(directionVector.Y, directionVector.X)
                        points = {
                            Vector2.new(arrowPosition.X, arrowPosition.Y),
                            Vector2.new(arrowPosition.X - arrowSize * math.cos(angle + math.rad(30)), arrowPosition.Y - arrowSize * math.sin(angle + math.rad(30))),
                            Vector2.new(arrowPosition.X - arrowSize * math.cos(angle - math.rad(30)), arrowPosition.Y - arrowSize * math.sin(angle - math.rad(30)))
                        }
                    end
                    
                    esp.Arrow.PointA = points[1]
                    esp.Arrow.PointB = points[2]
                    esp.Arrow.PointC = points[3]
                    esp.Arrow.Visible = true
                    
                    if Esp.Rainbow then
                        esp.Arrow.Color = Color3.fromHSV(tick() % 5 / 5, 1, 1)
                    else
                        esp.Arrow.Color = Esp.Arrows_Accent
                    end
                else
                    esp.Arrow.Visible = false
                end
                
                for name, obj in pairs(esp) do
                    if name ~= "Arrow" then
                        obj.Visible = false
                    end
                end
                continue
            else
                esp.Arrow.Visible = false
            end
            
            local topLeft = Camera:WorldToViewportPoint(cf * CFrame.new(-size.X/2, size.Y/2, 0).Position)
            local topRight = Camera:WorldToViewportPoint(cf * CFrame.new(size.X/2, size.Y/2, 0).Position)
            local bottomLeft = Camera:WorldToViewportPoint(cf * CFrame.new(-size.X/2, -size.Y/2, 0).Position)
            local bottomRight = Camera:WorldToViewportPoint(cf * CFrame.new(size.X/2, -size.Y/2, 0).Position)
            
            local boxWidth = math.max(math.abs(topRight.X - topLeft.X), 3)
            local boxHeight = math.max(math.abs(bottomLeft.Y - topLeft.Y), 3)
            local boxPosition = Vector2.new(math.min(topLeft.X, topRight.X, bottomLeft.X, bottomRight.X), math.min(topLeft.Y, topRight.Y, bottomLeft.Y, bottomRight.Y))
            
            if Esp.Boxes then
                esp.Box.Size = Vector2.new(boxWidth, boxHeight)
                esp.Box.Position = boxPosition
                esp.Box.Color = Esp.Box_Accent
                esp.Box.Visible = true
                
                esp.BoxOutline.Size = Vector2.new(boxWidth, boxHeight)
                esp.BoxOutline.Position = boxPosition
                esp.BoxOutline.Visible = true
            else
                esp.Box.Visible = false
                esp.BoxOutline.Visible = false
            end
            
            if Esp.Healthbar then
                local health = humanoid.Health
                local maxHealth = humanoid.MaxHealth
                local healthRatio = math.clamp(health / maxHealth, 0, 1)
                
                local healthColor
                if Esp.Lerp then
                    if healthRatio > 0.5 then
                        healthColor = Esp.Gradient3:Lerp(Esp.Gradient2, (1 - healthRatio) * 2)
                    else
                        healthColor = Esp.Gradient2:Lerp(Esp.Gradient1, (0.5 - healthRatio) * 2)
                    end
                else
                    healthColor = Esp.Gradient3
                end
                
                if Esp.Position == "Left" then
                    esp.HealthBarOutline.Size = Vector2.new(Esp.Width + 2, boxHeight)
                    esp.HealthBarOutline.Position = Vector2.new(boxPosition.X - Esp.Width - 4, boxPosition.Y)
                    esp.HealthBarOutline.Visible = true
                    
                    esp.HealthBar.Size = Vector2.new(Esp.Width, boxHeight * healthRatio)
                    esp.HealthBar.Position = Vector2.new(boxPosition.X - Esp.Width - 4, boxPosition.Y + boxHeight * (1 - healthRatio))
                    esp.HealthBar.Color = healthColor
                    esp.HealthBar.Visible = true
                    
                    if Esp.Healthtext then
                        esp.HealthText.Text = math.floor(health) .. "/" .. math.floor(maxHealth)
                        esp.HealthText.Position = Vector2.new(boxPosition.X - Esp.Width - 4, boxPosition.Y + boxHeight)
                        esp.HealthText.Visible = true
                    else
                        esp.HealthText.Visible = false
                    end
                else
                    esp.HealthBarOutline.Size = Vector2.new(boxWidth, Esp.Width + 2)
                    esp.HealthBarOutline.Position = Vector2.new(boxPosition.X, boxPosition.Y + boxHeight + 2)
                    esp.HealthBarOutline.Visible = true
                    
                    esp.HealthBar.Size = Vector2.new(boxWidth * healthRatio, Esp.Width)
                    esp.HealthBar.Position = Vector2.new(boxPosition.X, boxPosition.Y + boxHeight + 2)
                    esp.HealthBar.Color = healthColor
                    esp.HealthBar.Visible = true
                    
                    if Esp.Healthtext then
                        esp.HealthText.Text = math.floor(health) .. "/" .. math.floor(maxHealth)
                        esp.HealthText.Position = Vector2.new(boxPosition.X + boxWidth / 2, boxPosition.Y + boxHeight + Esp.Width + 4)
                        esp.HealthText.Visible = true
                    else
                        esp.HealthText.Visible = false
                    end
                end
            else
                esp.HealthBar.Visible = false
                esp.HealthBarOutline.Visible = false
                esp.HealthText.Visible = false
            end
            
            if Esp.Names then
                esp.Name.Text = player.Name
                esp.Name.Position = Vector2.new(boxPosition.X + boxWidth / 2, boxPosition.Y - esp.Name.TextBounds.Y - 2)
                esp.Name.Color = Esp.Accent
                esp.Name.Visible = true
            else
                esp.Name.Visible = false
            end
            
            if Esp.Distance then
                local distanceText
                if Esp.Measurement == "Studs" then
                    distanceText = math.floor(distance) .. " studs"
                else
                    distanceText = math.floor(distance / 3.571) .. "m"
                end
                
                esp.Distance.Text = distanceText
                esp.Distance.Position = Vector2.new(boxPosition.X + boxWidth / 2, boxPosition.Y + boxHeight + esp.Distance.TextBounds.Y)
                esp.Distance.Color = Esp.Distance_Accent
                esp.Distance.Visible = true
            else
                esp.Distance.Visible = false
            end
            
            if Esp.Weapon then
                local weaponName = Script.Functions.get_tool_name(character)
                esp.Weapon.Text = weaponName
                esp.Weapon.Position = Vector2.new(boxPosition.X + boxWidth / 2, boxPosition.Y + boxHeight + (Esp.Distance and esp.Distance.TextBounds.Y * 2 + 2 or esp.Weapon.TextBounds.Y))
                esp.Weapon.Color = Esp.Weapon_Accent
                esp.Weapon.Visible = true
            else
                esp.Weapon.Visible = false
            end
            
            if Esp.Highlight then
                if not character:FindFirstChild("Highlight") then
                    local highlight = Instance.new("Highlight")
                    highlight.FillColor = Esp.Highlight_Accent
                    highlight.OutlineColor = Color3.new(0, 0, 0)
                    highlight.FillTransparency = 0.5
                    highlight.OutlineTransparency = 0
                    highlight.Parent = character
                else
                    character.Highlight.FillColor = Esp.Highlight_Accent
                end
            else
                local existingHighlight = character:FindFirstChild("Highlight")
                if existingHighlight and existingHighlight.Name == "Highlight" then
                    existingHighlight:Destroy()
                end
            end
        end
    end)
    Players.PlayerRemoving:Connect(function(player)
        removeEspObjects(player)
    end)
    Script.Functions.CreateConnection(RunService.RenderStepped, LPH_NO_VIRTUALIZE(function()
        updatePlayerESP()
    end))
end
 
task.spawn(function()
    if PuppyWare.Combat.rage_bot.Rage.Auto_Reload then
        Script.Functions.startAutoReload()
    end
    
    if PuppyWare.Combat.rage_bot.Rage.Anti_Stomp then
        Script.Functions.startAntiStomp()
    end
    
    if PuppyWare.Combat.rage_bot.Rage.Auto_Stomp then
        Script.Functions.autoStompNearbyPlayers()
    end
end)
 
pcall(function()
    local library, modules, connection, utility = {}, {}, {}, {};
    -- 
    local Services = setmetatable({}, {
        __index = function(t, k)
            if k == "game" then
                return game;
            else
                return game:GetService(k);
            end
        end
    })
    
    local run_service = Services.RunService;
    local tween_service = Services.TweenService;
    local user_input_service = Services.UserInputService;
    local http_service = Services.HttpService;
    local text_service = Services.TextService;
    
    local mouse = user_input_service:GetMouseLocation()
    local rgb = Color3.fromRGB
    local dim2 = UDim2.new
    local dim = UDim.new
    local vec2 = Vector2.new
    function numkey(t, v)
        return NumberSequenceKeypoint.new(t, v)
    end
    
    function numseq(tbl)
        return NumberSequence.new(tbl)
    end
    
    library = {
        start = os.clock(),
        debug = true,
        fonts = {
            main = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
            sub_main = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal)
        },
        images = {
            icons = { 
                tab = 'rbxassetid://93403571101935', -- paper
                side_bar = 'rbxassetid://72968374894897',
                arrows = {
                    shorter = {
                        left = 'rbxassetid://71232767826177',
                        right = 'rbxassetid://71232767826177';
                    },
                    left = 'rbxassetid://126395927124786',
                    right = 'rbxassetid://114302209803697',
                    down = 'rbxassetid://82570172465592';
                },
                search = 'rbxassetid://122831998241429';
            };
        },
        colors = {
            accent = Color3.fromRGB(165, 204, 237),
            arrow_down = Color3.fromRGB(162, 162, 162),
            text = {
                ['Title'] = Color3.fromRGB(151, 151, 151),
                ['Section-Title'] = Color3.fromRGB(162, 162, 162),
                ['Sub-Title'] = Color3.fromRGB(82, 82, 82)
            },
            selected = Color3.fromRGB(165, 204, 237),
            deselected = Color3.fromRGB(231, 231, 231);
        },
    
        active = false,
        flags = {},
        unnamedflags = {},
        fps = 0,
        ping = 0,
        connections = {},
        directories = {
            'puppyware',
            'puppyware/cfgs'
        },
        dragging = nil,
        holder = nil,
        keys = {
            [Enum.KeyCode.Space] = "space",
            [Enum.KeyCode.Return] = "return",
            [Enum.KeyCode.Escape] = "esc",
            [Enum.KeyCode.LeftShift] = "lshift",
            [Enum.KeyCode.RightShift] = "rshift",
            [Enum.KeyCode.LeftControl] = "lctrl",
            [Enum.KeyCode.RightControl] = "rctrl",
            [Enum.KeyCode.LeftAlt] = "lalt",
            [Enum.KeyCode.RightAlt] = "ralt",
            [Enum.KeyCode.CapsLock] = "caps",
            [Enum.KeyCode.Backspace] = "bksp",
            [Enum.KeyCode.One] = "1",
            [Enum.KeyCode.Two] = "2",
            [Enum.KeyCode.Three] = "3",
            [Enum.KeyCode.Four] = "4",
            [Enum.KeyCode.Five] = "5",
            [Enum.KeyCode.Six] = "6",
            [Enum.KeyCode.Seven] = "7",
            [Enum.KeyCode.Eight] = "8",
            [Enum.KeyCode.Nine] = "9",
            [Enum.KeyCode.Zero] = "0",
            [Enum.KeyCode.KeypadOne] = "num1",
            [Enum.KeyCode.KeypadTwo] = "num2",
            [Enum.KeyCode.KeypadThree] = "Num3",
            [Enum.KeyCode.KeypadFour] = "num4",
            [Enum.KeyCode.KeypadFive] = "num5",
            [Enum.KeyCode.KeypadSix] = "num6",
            [Enum.KeyCode.KeypadSeven] = "num7",
            [Enum.KeyCode.KeypadEight] = "num8",
            [Enum.KeyCode.KeypadNine] = "num9",
            [Enum.KeyCode.KeypadZero] = "num0",
            [Enum.KeyCode.Minus] = "-",
            [Enum.KeyCode.Equals] = "=",
            [Enum.KeyCode.Tilde] = "~",
            [Enum.KeyCode.LeftBracket] = "[",
            [Enum.KeyCode.RightBracket] = "]",
            [Enum.KeyCode.RightParenthesis] = ")",
            [Enum.KeyCode.LeftParenthesis] = "(",
            [Enum.KeyCode.Semicolon] = ",",
            [Enum.KeyCode.Quote] = "'",
            [Enum.KeyCode.BackSlash] = "\\",
            [Enum.KeyCode.Comma] = ",",
            [Enum.KeyCode.Period] = ".",
            [Enum.KeyCode.Slash] = "/",
            [Enum.KeyCode.Asterisk] = "*",
            [Enum.KeyCode.Plus] = "+",
            [Enum.KeyCode.Backquote] = "`",
            [Enum.UserInputType.MouseButton1] = "m1",
            [Enum.UserInputType.MouseButton2] = "m2",
            [Enum.UserInputType.MouseButton3] = "m3"
        },
        notifications = {};
    }
    --
    
    do
        --
            if not isfolder("puppyware") then
                makefolder("puppyware")
            end
            if not isfolder("puppyware/cfgs") then
                makefolder("puppyware/cfgs")
            end
        --
    end
    --
    local notification_holder = Instance.new('ScreenGui', gethui())
    --
    function library.notify(data)
        local y_offset = 10;
    
        local notif = Instance.new("Frame")
        notif.Name = "\0"
        notif.BackgroundTransparency = 1
        notif.Position = UDim2.new(0, 10, 0, y_offset)
        notif.Size = UDim2.new(0, 250, 0, 22)
        notif.AnchorPoint = Vector2.zero
        notif.BorderSizePixel = 0
        notif.BackgroundColor3 = Color3.fromRGB(150, 150, 150)
        notif.Parent = notification_holder
    
        local stroke = Instance.new("UIStroke", notif)
        stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
        stroke.Thickness = 2
        stroke.Color = Color3.fromRGB(91, 91, 91)
        stroke.Transparency = 1
    
        local text = Instance.new("TextLabel", notif)
        text.FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium)
        text.TextColor3 = Color3.new()
        text.TextTransparency = 1
        text.BackgroundTransparency = 1
        text.TextXAlignment = Enum.TextXAlignment.Left
        text.Size = UDim2.fromScale(1, 1)
        text.AnchorPoint = Vector2.new(0.5, 0.5)
        text.Position = UDim2.fromScale(0.5, 0.5)
        text.BorderSizePixel = 0
        text.TextSize = 16
        text.Text = data.Text or "Notification"
        Instance.new("UIPadding", text).PaddingLeft = UDim.new(0, 6)
    
        local bar = Instance.new("Frame", notif)
        bar.Name = "\0"
        bar.AnchorPoint = Vector2.new(0, 1)
        bar.Position = UDim2.new(0, 2, 1, -1)
        bar.Size = UDim2.new(0, 0, 0, 2)
        bar.BorderSizePixel = 0
        bar.BackgroundColor3 = Color3.fromRGB(23, 134, 248)
        bar.BackgroundTransparency = 0.15
        Instance.new("UICorner", bar).CornerRadius = UDim.new(0, 64)
    
        game:GetService("RunService").RenderStepped:Wait()
        local w, d = text.TextBounds.X + 10, data.Delay or 3.5
        notif.Size = UDim2.new(0, w, 0, 22)
    
        tween_service:Create(bar, TweenInfo.new(d, Enum.EasingStyle.Linear), {Size = UDim2.new(0, w - 4, 0, 2)}):Play()
        tween_service:Create(notif, TweenInfo.new(0.4), {BackgroundTransparency = 0.65}):Play()
        tween_service:Create(text, TweenInfo.new(0.4), {TextTransparency = 0.25}):Play()
        tween_service:Create(stroke, TweenInfo.new(0.4), {Transparency = 0.45}):Play()
    
        y_offset += 32
    
        task.delay(d, function()
            tween_service:Create(notif, TweenInfo.new(0.4), {BackgroundTransparency = 1}):Play()
            tween_service:Create(text, TweenInfo.new(0.4), {TextTransparency = 1}):Play()
            local s = tween_service:Create(stroke, TweenInfo.new(0.4), {Transparency = 1})
            s:Play(); s.Completed:Wait()
            notif:Destroy()
    
            y_offset = 10
            for _, v in ipairs(library.notifications) do
                if v:IsA("Frame") then
                    v.Position = UDim2.new(0, 10, 0, y_offset)
                    y_offset += 32
                end
            end
        end)
    
        return notif
    end
    --
    
    function save_config(name)
        local config = {}
    
        for flag, obj in pairs(library.flags) do
            if string.find(flag, "config") then continue end
    
            if typeof(obj) == "table" and obj.Set then
                if obj.state ~= nil and obj.key then
                    config[flag] = { state = obj.state, key = obj.key }
                else
                    config[flag] = obj.State
                end
            else
                config[flag] = obj
            end
        end
    
        writefile("puppyware/cfgs/" .. name .. ".cfg", http_service:JSONEncode(config))
    end
    
    function load_config(name)
        local file_path = "puppyware/cfgs/" .. name .. ".cfg"
        local raw = readfile(file_path)
        local data = http_service:JSONDecode(raw)
    
        for flag, new_val in pairs(data) do
            if not library.objects[flag] then
                library.notify({
                    Text = "Invalid config file!",
                    Delay = 3.5
                })
            end
            local obj = library.objects[flag]
            local old_val = library.flags[flag]
    
            if obj and typeof(obj.Set) == "function" then
                if typeof(new_val) == "table" and new_val.state ~= nil and new_val.key then
                    obj:Set(new_val.state, new_val.key)
                else
                    obj:Set(new_val)
                end
            else
                library.flags[flag] = new_val
            end
        end
    end
    
    local function get_config_files()
        local list = listfiles("puppyware/cfgs")
        local out = {}
        for _, file in ipairs(list) do
            local name = file:match("([^/\\]+)%.cfg$")
            if name then table.insert(out, name) end
        end
        return out
    end
    --
    utility = utility or {}
    flags = flags or {}
    --
    utility.new = function(class, params)
        local instance = Instance.new(class)
        if params then
            for prop, v in pairs(params) do
                instance[prop] = v
            end
        end
        return instance
    end
    
    utility.connection = function(signal, callback)
        return signal:Connect(callback)
    end
    
    utility.disconnect = function(connection)
        connection:Disconnect()
    end
    
    utility.render_functions = {}
    
    utility.manage_render_stepped = function(name, func)
        utility.render_functions[name] = func or nil
    end
    
    utility.update_section_size = function(v,tab_holder)
        local layout = tab_holder:FindFirstChildOfClass("UIListLayout")
        if layout then
            v.Size = UDim2.new(1, 0, 0, layout.AbsoluteContentSize.Y + 20)
        end
    end
    
    utility.is_mouse_over = function(obj)
        local abs_pos, abs_size = obj.AbsolutePosition, obj.AbsoluteSize
        local mouse = user_input_service:GetMouseLocation()
        return mouse.X >= abs_pos.X and mouse.X <= abs_pos.X + abs_size.X
            and mouse.Y >= abs_pos.Y and mouse.Y <= abs_pos.Y + abs_size.Y
    end
    
    utility.drag = function(obj)
        local drag_input, drag_start, start_pos
    
        local function update(input)
            local delta = input.Position - drag_start
            obj.Position = UDim2.new(start_pos.X.Scale, start_pos.X.Offset + delta.X, start_pos.Y.Scale, start_pos.Y.Offset + delta.Y)
        end
    
        obj.InputBegan:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                library.dragging = true
                drag_start = input.Position
                start_pos = obj.Position
                input.Changed:Connect(function()
                    if input.UserInputState == Enum.UserInputState.End then
                        library.dragging = false
                    end
                end)
            end
        end)
    
        obj.InputChanged:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
                drag_input = input
            end
        end)
    
        user_input_service.InputChanged:Connect(function(input)
            if input == drag_input and library.dragging then
                update(input)
            end
        end)
    end
    
    utility.round = function(int, step)
        return step * math.floor(int / step)
    end
    
    utility.auto_center = function(obj)
        obj.AnchorPoint = Vector2.new(0.5, 0.5)
        obj.Position = UDim2.new(0.5, 0, 0.5, 0)
    end
    
    utility.typewriter = function(obj, text, speed, repeat_text)
        repeat_text = repeat_text or true
        obj.Text = ''
        speed = speed or 0.05
    
        local function type_out(txt)
            for i = 1, #txt do
                obj.Text = string.sub(txt, 1, i)
                task.wait(speed)
            end
        end
    
        coroutine.wrap(function()
            repeat
                if typeof(text) == 'string' then
                    type_out(text)
                elseif typeof(text) == 'table' then
                    for _, txt in ipairs(text) do
                        type_out(txt)
                        task.wait(1)
                    end
                end
                task.wait(1)
            until not repeat_text
        end)()
    end
    
    utility.handle_click = function(obj, callback)
        obj.InputBegan:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then
                callback()
            end
        end)
    end
    
    utility.show_ui = function(obj, bool)
        obj.Enabled = bool or false
    end
    
    local holder = utility.new("ScreenGui", {
        Name = '2uhn35r23uji4n23iu423jn4i23o';
        ResetOnSpawn = false;
        ZIndexBehavior = Enum.ZIndexBehavior.Sibling;
        Parent = gethui();
    });
    
    
    library.holder = holder
    
        if library.holder then
            local last_time = tick()
    
            local connection;
            connection = utility.connection(run_service.RenderStepped, function()
    
                local current_time = tick()
                
                library.fps = math.floor(1 / (current_time - last_time))
                last_time = current_time
    
                --
                for _, func in pairs(utility.render_functions) do
                    func()
                end
                --
            end)
    
            function library.window(params)
                if not params then params = {} end
    
                library.objects = library.objects or {};
                
                local window, strokes, gradient, images, corner = {}, {}, {}, {}, {};
                local padding, layout, text_label, text_box = {}, {}, {}, {};
                
                function utility.add(Type, Parent, Properties)
                    local UID = Parent.Name .. "_" .. (Parent.Parent and Parent.Parent.Name or "Root")
                    
                    local Element = utility.new(Type, Properties)
                    Element.Parent = Parent  
                
                    if Type == "UIStroke" then
                        strokes[UID] = Element
                    elseif Type == "UIGradient" then
                        gradient[UID] = Element
                    elseif Type == "UIListLayout" then
                        layout[UID] = Element
                    elseif Type == "UIPadding" then
                        padding[UID] = Element
                    elseif Type == 'UICorner' then
                        corner[UID] = Element
                    end
                
                    return Element
                end
    
                window['1'] = utility.new( "Frame" , {
                    Parent = library.holder, -- Core
                    Name = "\0";
                    Position = dim2(0.146, 0, 0.255, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 690, 0, 440);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                });
                --
                    utility.drag(window["1"])
                    utility.auto_center(window['1'])
                --
                utility.add( "UICorner", window['1'], {
                    CornerRadius = dim(0, 6)
                });
                --
                utility.add("UIStroke", window['1'], {
                    Color = rgb(113, 113, 113);
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
                });
                --
                window['2'] = utility.new( "Frame" , {
                    Parent = window['1'], --Sidebar
                    Name = "\0";
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0.029, 170, 1, 0);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(203, 203, 203)
                })
                --
                utility.add("UICorner", window['2'], {
                    CornerRadius = dim(0, 6)
                });
                --
                window['3'] = utility.new( "Frame" , {
                    AnchorPoint = vec2(0.5, 0.5); -- Fill
                    Parent = window['2'];
                    Name = "\0";
                    Position = dim2(1, -2, 0.5, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0.02, 0, 1, 0);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(203, 203, 203)
                })
                window['4'] = utility.new( "Frame" , {
                    Parent = window['2']; -- Separator
                    Name = "\0";
                    Position = dim2(0, 189, 0, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 1, 1, 0);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(151, 151, 151)
                })
                --
                window['5'] = utility.new("Frame" , {
                    Parent = window['2']; --	MenuContainer
                    Name = "\0";
                    BackgroundTransparency = 1;
                    Position = dim2(0, 20, 0, 20);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 48, 0, 12);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                })
                utility.add( "UIListLayout" ,window['5'],{
                    Padding = dim(0, 4);
                    SortOrder = Enum.SortOrder.LayoutOrder;
                    FillDirection = Enum.FillDirection.Horizontal;
                });
                --
                window['6'] = utility.new("Frame", {
                    Name = "\0"; -- Close
                    Parent = window['5'];
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 12, 0, 12);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(240, 78, 89)
                });
                window['7'] = utility.new("Frame", {
                    Name = "\0"; -- Minimize
                    Parent = window['5'];
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 12, 0, 12);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(246, 190, 54)
                });
                window['8'] = utility.new("Frame", {
                    Name = "\0"; -- Open
                    Parent = window['5'];
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 12, 0, 12);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(55, 225, 67)
                });
                --
                user_input_service.InputBegan:Connect(function(input, c)
                    if c then return end
                    if input.UserInputType == Enum.UserInputType.Keyboard and input.KeyCode == Enum.KeyCode.RightAlt and not library.holder.Enabled then
                        library.holder.Enabled = true
                    end
                end)
                --
                for i = 6, 8 do
                    utility.add("UICorner", window[tostring(i)], {
                        CornerRadius = dim(0, 6)
                    })
    
                    utility.handle_click(window[tostring(i)], function()
                        if library.debug then
                            if i == 6 then
                                utility.show_ui(library.holder, false)
                                library.notify({
                                    Text = "Window closed, press RightAlt to open",
                                    Delay = 3.5
                                })
                            end
                        end
                    end)
                end
                --
                window['9'] = utility.new("ScrollingFrame", {
                    Name = "\0"; -- SectionHolder
                    Parent = window['2'];
                    BackgroundTransparency = 1;
                    Position = dim2(0, 10, 0, 55);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0.053, 160, 1, -75);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255);
                    AutomaticCanvasSize = Enum.AutomaticSize.Y;
                    ScrollBarThickness = 0; 
                    ScrollBarImageTransparency = 1;
                    ScrollBarImageColor3 = rgb(162, 162, 162);
                });
                utility.add( "UIListLayout" ,window['9'],{
                    Padding = dim(0, 28);
                    SortOrder = Enum.SortOrder.LayoutOrder;
                    HorizontalFlex = Enum.UIFlexAlignment.Fill
                });
                --
                window['10'] = utility.new("Frame", {
                    Parent =  window['1']; --Topbar
                    Name = "\0";
                    Position = dim2(0, 190, 0, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 497, 0, 50);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(239, 239, 239)
                })
                utility.add( "UIListLayout",window['10'],{
                    Padding = dim(0, 10);
                    SortOrder = Enum.SortOrder.LayoutOrder;
                    VerticalAlignment = Enum.VerticalAlignment.Center;
                    FillDirection = Enum.FillDirection.Horizontal;
                });
                utility.add("UIPadding", window['10'], {
                    PaddingLeft = dim(0, 10);
                });
                --
                images['1'] = utility.new("ImageLabel", {
                    ImageColor3 = rgb(151, 151, 151);
                    ScaleType = Enum.ScaleType.Fit;
                    BorderColor3 = rgb(0, 0, 0);
                    Image = library.images.icons.side_bar;
                    BackgroundTransparency = 1;
                    Parent = window['10'];
                    Size = dim2(0, 30, 0, 30);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                })
                --
                window['11'] = utility.new("Frame" , {
                    Parent = window['10']; -- icon_holder
                    Name = "\0";
                    BackgroundTransparency = 1;
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 70, 0, 35);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                });
                images['2'] = utility.new( "ImageLabel" , {
                    ImageColor3 = rgb(151, 151, 151); -- left_arrow
                    ScaleType = Enum.ScaleType.Fit;
                    BorderColor3 = rgb(0, 0, 0);
                    Parent = window['11'];
                    Name = "\0";
                    AnchorPoint = vec2(0, 0.5);
                    Image = "rbxassetid://126395927124786";
                    BackgroundTransparency = 1;
                    Position = dim2(0, 0, 0.5, 0);
                    Size = dim2(0.5, -5, 0.45, 0);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                });
                images['3'] = utility.new( "ImageLabel" , {
                    ImageColor3 = rgb(151, 151, 151); -- right_arrow
                    ScaleType = Enum.ScaleType.Fit;
                    BorderColor3 = rgb(0, 0, 0);
                    Parent = window['11'];
                    Name = "\0";
                    AnchorPoint = vec2(1, 0.5);
                    Image = "rbxassetid://114302209803697";
                    BackgroundTransparency = 1;
                    Position = dim2(1, 0, 0.5, 0);
                    Size = dim2(0.5, -5, 0.45, 0);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                });
                --
                window['12'] = utility.new("Frame", {
                    Parent = window['10']; -- title_holder
                    Name = "\0";
                    BackgroundTransparency = 1;
                    Position = dim2(0.258, 0, 0.150, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 200, 0, 30);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                })
                
                utility.add("UIPadding", window['12'], {
                    PaddingLeft = dim(0, -5);
                });
                
                text_label['1'] = utility.new( "TextLabel" , {
                    FontFace = library.fonts.main;
                    TextColor3 = rgb(82, 82, 82);
                    BorderColor3 = rgb(0, 0, 0);
                    Text = params.title;
                    Parent = window['12'];
                    Name = "\0";
                    Size = dim2(1, 0, 0.5, 0);
                    BackgroundTransparency = 1;
                    TextXAlignment = Enum.TextXAlignment.Left;
                    BorderSizePixel = 0;
                    TextSize = 14;
                    BackgroundColor3 = rgb(255, 255, 255)
                });
                text_label['2'] = utility.new( "TextLabel" , {
                    FontFace = library.fonts.sub_main;
                    TextColor3 =  rgb(151, 151, 151);
                    BorderColor3 = rgb(0, 0, 0);
                    Text = params.sub_title;
                    Parent = window['12'];
                    Name = "\0";
                    Size = dim2(1, 0, 0.5, 0);
                    Position = dim2(0, 0, 0.5, 0);
                    BackgroundTransparency = 1;
                    TextXAlignment = Enum.TextXAlignment.Left;
                    BorderSizePixel = 0;
                    TextSize = 12;
                    BackgroundColor3 = rgb(255, 255, 255)
                });
                --
                window['13'] = utility.new( "Frame" , {
                    Parent = window['10'];
                    Name = "\0";
                    BackgroundTransparency = 1;
                    Position = dim2(0.692, 0, 0.150, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(0, 139, 0, 30);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                });
                
                images['4'] = utility.new("ImageLabel", {
                    ImageColor3 = rgb(151, 151, 151);
                    ScaleType = Enum.ScaleType.Fit;
                    BorderColor3 = rgb(0, 0, 0);
                    Parent = window['13'];
                    Name = "\0";
                    AnchorPoint = vec2(0, 0.5);
                    Image = "rbxassetid://122831998241429";
                    BackgroundTransparency = 1;
                    Position = dim2(0, 20, 0.5, 0);
                    Size = dim2(0, 16, 0.5, -1);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                })
                
                window['14'] = utility.new("Frame", {
                    Parent = window['13'];
                    BackgroundTransparency = 1;
                    Position = dim2(0, 12, 0, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    Size = dim2(1.0292,-16, 1, 0);
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(255, 255, 255)
                })
                
                utility.add("UICorner", window['14']);
                utility.add("UIStroke", window['14'],{
                    Color = rgb(214, 214, 214);
                    ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
                });
                text_box['1'] = utility.new('TextBox', {
                    Parent = window['14'];
                    CursorPosition = -1;
                    Size = dim2(0.7639, 0, 1, 0);
                    TextColor3 = rgb(151, 151, 151);
                    BorderColor3 = rgb(0, 0, 0);
                    Text = "";
                    Position = dim2(0.61805, 0, 0.5, 1);
                    BorderSizePixel = 0;
                    AnchorPoint = vec2(0.5, 0.5);
                    FontFace = library.fonts.main;
                    BackgroundTransparency = 1;
                    PlaceholderColor3 = rgb(151, 151, 151);
                    TextXAlignment = Enum.TextXAlignment.Left;
                    PlaceholderText = "Search";
                    TextSize = 16;
                    BackgroundColor3 = rgb(255, 255, 255)
                })
    
                utility.add("UIPadding", text_box['1'], {
                    PaddingBottom = dim(0, 2);
                });
                --
                window['15'] = utility.new( "Frame" , {
                    Parent = window['1'];
                    Size = dim2(0, 500, 0, 51);
                    Name = "\0";
                    Position = dim2(0, 190, 0, 0);
                    BorderColor3 = rgb(0, 0, 0);
                    ZIndex = -1;
                    BorderSizePixel = 0;
                    BackgroundColor3 = rgb(239, 239, 239)
                });
                utility.add("UICorner", window['15'], {
                    CornerRadius = dim(0, 6)
                })
                window['16'] = utility.new("ScrollingFrame" , {
                    ScrollBarImageColor3 = rgb(204, 204, 204);
                    Active = true;
                    AutomaticCanvasSize = Enum.AutomaticSize.Y;
                    ScrollBarThickness = 6;
                    Parent = window['1'];
                    Size = dim2(0, 500, 1, -54);
                    Name = "\0";
                    Position = dim2(0, 190, 0, 50);
                    BackgroundColor3 = rgb(255, 255, 255);
                    BorderColor3 = rgb(0, 0, 0);
                    BorderSizePixel = 0;
                    CanvasSize = dim2(0, 0, 1, 0)
                });
                utility.add("UIPadding", window['16'], {
                    PaddingTop = dim(0, 11);
                    PaddingBottom = dim(0, 5);
                    PaddingRight = dim(0, 11);
                    PaddingLeft = dim(0, 11)
                })
            
                utility.add("UIListLayout", window['16'], {
                    Padding = dim(0, 6);
                    SortOrder = Enum.SortOrder.LayoutOrder
                })
                local selected_tab = nil
                local selected_tab_ref = nil
    
                function window.section(params)
                    if not params then params = {} end
    
                    local section = {
                        title = params.Name or params.name or 'Section Title';
                        collapsed = false;
                    }
    
                    local section_container = utility.new("Frame", {
                        Parent = window['9'];
                        BackgroundTransparency = 1;
                        Name = "\0";
                        BorderColor3 = rgb(0, 0, 0);
                        Size = dim2(0, 150, 0, 80);
                        BorderSizePixel = 0;
                        --ipsDescendants = true;
                        BackgroundColor3 = rgb(255, 255, 255);
                    })
    
                    local title_holder = utility.new("Frame", {
                        Parent = section_container;
                        BackgroundTransparency = 1;
                        Name = "\0";
                        BorderColor3 = rgb(0, 0, 0);
                        Size = dim2(1, 0, 0, 15);
                        BorderSizePixel = 0;
                        BackgroundColor3 = rgb(255, 255, 255)
                    });
    
                    utility.handle_click(title_holder, function()
                        section.collapsed = not section.collapsed
                        section_container.Size = section.collapsed and dim2(0, 150, 0, 15) or dim2(0, 150, 0, 80)
    
                        for _, v in pairs(section_container:GetChildren()) do
                            if v.Name == "tab_holder" then
                                v.Visible = not section.collapsed
                            end
                        end
                    end)
    
                    utility.new("TextLabel", {
                        Parent = title_holder;
                        TextColor3 = rgb(162, 162, 162);
                        BorderColor3 = rgb(0, 0, 0);
                        Text = params.Name;
                        Size = dim2(0.953, 0, 1, 0);
                        Position = dim2(0.535, 0, 0.5, 0);
                        AnchorPoint = vec2(0.5, 0.5);
                        BorderSizePixel = 0;
                        BackgroundTransparency = 1;
                        TextXAlignment = Enum.TextXAlignment.Left;
                        FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Bold, Enum.FontStyle.Normal);
                        TextYAlignment = Enum.TextYAlignment.Top;
                        TextSize = 14;
                        BackgroundColor3 = rgb(255, 255, 255)
                    });
    
                    utility.new("ImageLabel", {
                        ImageColor3 = rgb(162, 162, 162);
                        ScaleType = Enum.ScaleType.Fit;
                        BorderColor3 = rgb(0, 0, 0);
                        Parent = title_holder;
                        Name = "\0";
                        AnchorPoint = vec2(1, 0);
                        Image = "rbxassetid://82570172465592";
                        BackgroundTransparency = 1;
                        Position = dim2(1, 0, 0, 0);
                        Size = dim2(0, 15, 1, -3);
                        BorderSizePixel = 0;
                        BackgroundColor3 = rgb(255, 255, 255)
                    });
    
                    function section.tab(params)
                        if not params then params = {} end
    
                        local tab = {}
                        tab._group_boxes = {}
    
                        section._tab_holder = section._tab_holder or utility.new("ScrollingFrame", {
                            BorderColor3 = rgb(0, 0, 0);
                            AnchorPoint = vec2(0, 1);
                            Parent = section_container;
                            BackgroundTransparency = 1;
                            Position = dim2(0, 0, 1, 5);
                            Name = "tab_holder";
                            Size = dim2(1, 0, 1, -10);
                            BorderSizePixel = 0;
                            BackgroundColor3 = rgb(255, 255, 255);
                            ScrollBarThickness = 0;
                            AutomaticCanvasSize = Enum.AutomaticSize.Y;
                            CanvasSize = dim2(0, 0, 0, 0);
                        })
    
                        if not section._tab_holder:FindFirstChildOfClass("UIListLayout") then
                            utility.add("UIListLayout", section._tab_holder)
                        end
                        section._tab_holder.MouseEnter:Connect(function()
                            window['9'].ScrollingEnabled = false
                        end)
                        
                        section._tab_holder.MouseLeave:Connect(function()
                            window['9'].ScrollingEnabled = true
                        end)
                        local actual_tab_holder = utility.new("Frame", {
                            Name = "\0";
                            Parent = section._tab_holder;
                            BorderColor3 = rgb(0, 0, 0);
                            Size = dim2(1, 0, 0.5, -5);
                            BorderSizePixel = 0;
                            BackgroundTransparency = 1;
                            BackgroundColor3 = rgb(23, 134, 248)
                        })
                        utility.add("UICorner", actual_tab_holder, {
                            CornerRadius = dim(0, 6)
                        })
    
                        local text_label_tab = utility.new("TextLabel", {
                            FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                            TextColor3 = rgb(0, 0, 0);
                            BorderColor3 = rgb(0, 0, 0);
                            Parent = actual_tab_holder;
                            AnchorPoint = vec2(0, 0.5);
                            Size = dim2(1, 0, 1, 0);
                            BackgroundTransparency = 1;
                            TextXAlignment = Enum.TextXAlignment.Left;
                            Position = dim2(0, 0, 0.5, 0);
                            BorderSizePixel = 0;
                            TextSize = 14;
                            BackgroundColor3 = rgb(255, 255, 255);
                            Text = params.Name or "Tab"
                        })
                        utility.add("UIPadding", text_label_tab, {
                            PaddingTop = dim(0, 0);
                            PaddingLeft = dim(0, 30)
                        })
    
                        local image_icon = utility.new("ImageLabel", {
                            ScaleType = Enum.ScaleType.Fit;
                            BorderColor3 = rgb(0, 0, 0);
                            Parent = actual_tab_holder;
                            AnchorPoint = vec2(0, 0.5);
                            Image = "rbxassetid://93403571101935";
                            BackgroundTransparency = 1;
                            Position = dim2(0, 8, 0.5, 0);
                            Size = dim2(0, 15, 0, 15);
                            BorderSizePixel = 0;
                            ImageColor3 = rgb(23, 134, 248);
                            BackgroundColor3 = rgb(23, 134, 248);
                        })
    
                        utility.handle_click(actual_tab_holder, function()
                            if selected_tab and selected_tab ~= actual_tab_holder then
                                local lbl = selected_tab:FindFirstChildWhichIsA("TextLabel")
                                local img = selected_tab:FindFirstChildWhichIsA("ImageLabel")
                                if lbl then lbl.TextColor3 = rgb(0, 0, 0) end
                                if img then
                                    img.ImageColor3 = rgb(23, 134, 248)
                                    img.BackgroundTransparency = 1
                                end
                                selected_tab.BackgroundTransparency = 1
    
                                if selected_tab_ref then
                                    for _, box in pairs(selected_tab_ref._group_boxes) do
                                        box.Visible = false
                                    end
                                end
                            end
    
                            selected_tab = actual_tab_holder
                            selected_tab_ref = tab
    
                            local lbl = actual_tab_holder:FindFirstChildWhichIsA("TextLabel")
                            local img = actual_tab_holder:FindFirstChildWhichIsA("ImageLabel")
                            if lbl then lbl.TextColor3 = rgb(255, 255, 255) end
                            if img then
                                img.ImageColor3 = rgb(255, 255, 255)
                                img.BackgroundTransparency = 0
                            end
                            actual_tab_holder.BackgroundTransparency = 0
    
                            for _, box in pairs(tab._group_boxes) do
                                box.Visible = true
                            end
                        end)
                            function tab.group_box(params)
                                if not params then params = {} end
                                
                                local SectionContainer = utility.new("Frame", {
                                    Parent = window["16"];
                                    Name = (params.Name or params.name or "GroupBox");
                                    Size = dim2(0, 478, 0, 97);
                                    BorderColor3 = rgb(0, 0, 0);
                                    BorderSizePixel = 0;
                                    AutomaticSize = Enum.AutomaticSize.Y;
                                    BackgroundColor3 = rgb(253, 253, 253);
                                    Visible = false
                                })
    
                                utility.add("UIStroke", SectionContainer, {
                                    Color = rgb(214, 214, 214);
                                    ApplyStrokeMode = Enum.ApplyStrokeMode.Border;
                                    LineJoinMode = Enum.LineJoinMode.Round
                                })
    
                                utility.add("UICorner", SectionContainer, {
                                    CornerRadius = dim(0, 4)
                                })
                                
                                utility.add("UIListLayout", SectionContainer, {
                                    Padding = dim(0, 4),
                                    SortOrder = Enum.SortOrder.LayoutOrder,
                                    HorizontalFlex = Enum.UIFlexAlignment.Fill
                                })
                                
                                table.insert(tab._group_boxes, SectionContainer)
                                
                                local group_box = {}
                                group_box.__index = group_box
                                setmetatable(group_box, group_box)
                            
                            function group_box.button(params)
                                if not params then params = {} end
    
                                local button = {
                                    Title = params.name or params.Name or "Title",
                                    Button_Title = params.button_title or params.Button_Title or "Button",
                                    Sub_Title = params.sub_name or params.sub_name or "Sub-Title",
                                    Flag = params.flag or params.Flag or math.random(1, math.random(1, 1000)),
                                    State = params.Default or params.default or false,
                                    Callback = params.Callback or params.callback or function() end;
                                }
    
                                library.flags[button.Flag] = library.flags[button.Flag] or button.State;
                                
                                local separator_holder = utility.new( "Frame" , {
                                    Parent = SectionContainer;
                                    BackgroundTransparency = 1;
                                    Name = "\0";
                                    BorderColor3 = rgb(0, 0, 0);
                                    Size = dim2(0, 478, 0, 30);
                                    BorderSizePixel = 0;
                                    BackgroundColor3 = rgb(100, 100, 100)
                                });
    
                                utility.add("UICorner", separator_holder, {
                                    CornerRadius = dim(0, 4)
                                })
    
                                local title_holder =  utility.new( "Frame" , {
                                    BorderColor3 = rgb(0, 0, 0);
                                    Parent = separator_holder;
                                    AnchorPoint = vec2(0, 0.5);
                                    Name = "\0";
                                    BackgroundTransparency = 1;
                                    Position = dim2(0.023, 0, 0.5, 0);
                                    Size = dim2(0, 228, 0, 21);
                                    BorderSizePixel = 0;
                                    AutomaticSize = Enum.AutomaticSize.Y;
                                });
    
                                utility.new( "TextLabel" , {
                                    FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                                    Parent = title_holder;
                                    Active = true;
                                    BorderColor3 = rgb(0, 0, 0);
                                    Text = params.name;
                                    Name = "\0";
                                    Size = dim2(1, 0, 1, 0);
                                    AnchorPoint = vec2(0, 0.5);
                                    Position = dim2(0, 0, 0.5, 0);
                                    BackgroundTransparency = 1;
                                    TextXAlignment = Enum.TextXAlignment.Left;
                                    BorderSizePixel = 0;
                                    TextColor3 = rgb(82, 82, 82);
                                    TextSize = 14;
                                    BackgroundColor3 = rgb(255, 255, 255)
                                });
    
                                local actual_side_holder = utility.new( "Frame" , {
                                    BorderColor3 = rgb(0, 0, 0);
                                    AnchorPoint = vec2(1, 0.5);
                                    Parent = separator_holder;
                                    BackgroundTransparency = 1;
                                    Position = dim2(1, -20, 0.5, 0);
                                    Name = "\0";
                                    Size = dim2(0, 40, 0, 18);
                                    BorderSizePixel = 0;
                                });
    
                                local text_button = utility.new("TextButton", {
                                    FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal),
                                    TextColor3 = rgb(151, 151, 151),
                                    BorderColor3 = rgb(0, 0, 0),
                                    AnchorPoint = vec2(0.5, 0.5),
                                    Parent = actual_side_holder,
                                    AutoButtonColor = false,
                                    Position = dim2(0.5, 0, 0.5, 0),
                                    Size = dim2(1, 0, 1, 0),
                                    BorderSizePixel = 0,
                                    TextSize = 14,
                                    BackgroundColor3 = rgb(255, 255, 255),
                                    Text = params.button_title;
                                })
                                utility.add("UICorner", text_button, {
                                    CornerRadius = dim(0, 4)
                                })
                                utility.add("UIStroke", text_button, {
                                    Color = rgb(214, 214, 214),
                                    Transparency = 0.5,
                                    Thickness = 2,
                                    ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
                                })
    
                                utility.new( "Frame" , {
                                    Parent = separator_holder;
                                    Name = "\0";
                                    Position = dim2(0.0235, 0, 1, 0);
                                    BorderColor3 = rgb(0, 0, 0);
                                    Size = dim2(0.954, 0, 0, 1);
                                    BorderSizePixel = 0;
                                    BackgroundColor3 = rgb(214, 214, 214)
                                });
    
                            
                                text_button.MouseButton1Click:Connect(function()
                                    do
                                        if button.Flag then
                                            library.flags[button.Flag] = true
                                        end
    
                                        if button.Callback then
                                            button.Callback()
                                        end
                                    end
    
                                end)
                                
                                return button
                            end
                            --                            x
                            function group_box.dropdown(params)
                                params = params or {};
                            
                                local dropdown = {
                                    name = params.Name or params.name or 'new dropdown',
                                    sub_name = params.Sub_Name or params.sub_name or 'new dropdown',
                                    options = params.Options or params.options or { "option 1", "option 2", "option 3" },
                                    flag = params.Flag or params.flag,
                                    callback = params.Callback or params.callback or function() end,
                                    max = params.Max or params.max or 1,
                                    state = params.Default or params.default or nil,
                                    selected_options = params.Default or params.default or {},
                                    option_insts = {}
                                };
                            
                                library.objects[dropdown.flag] = dropdown;
                            
                                local separator_holder = utility.new("Frame", {
                                    Parent = SectionContainer,
                                    BackgroundTransparency = 1,
                                    Size = dim2(0, 478, 0, 45),
                                    BorderSizePixel = 0,
                                    ZIndex = 2,
                                    BackgroundColor3 = rgb(100, 100, 100)
                                });
                            
                                utility.new("Frame", {
                                    Parent = separator_holder,
                                    Position = dim2(0.0235, 0, 1, 0),
                                    Size = dim2(0.954, 0, 0, 1),
                                    BorderSizePixel = 0,
                                    BackgroundColor3 = rgb(214, 214, 214)
                                });
                            
                                local title_holder = utility.new("Frame", {
                                    Parent = separator_holder,
                                    Position = dim2(0.023, 0, 0, 0),
                                    Size = dim2(0, 228, 0, 42),
                                    AnchorPoint = vec2(0, 0),
                                    BackgroundTransparency = 1,
                                    BorderSizePixel = 0,
                                    AutomaticSize = Enum.AutomaticSize.Y
                                });
                            
                                local actual_title = utility.new("TextLabel", {
                                    FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
                                    TextColor3 = rgb(82, 82, 82);
                                    BorderColor3 = rgb(0, 0, 0);
                                    Text = dropdown.name;
                                    Size = dim2(0.5, 0, 0.5, 0);
                                    AnchorPoint = vec2(0, 0.5);
                                    Position = dim2(0, 0, 0.5, -10);
                                    BackgroundTransparency = 1;
                                    TextXAlignment = Enum.TextXAlignment.Left;
                                    BorderSizePixel = 0;
                                    TextYAlignment = Enum.TextYAlignment.Top;
                                    TextSize = 14;
                                    BackgroundColor3 = rgb(255, 255, 255);
                                    Parent = title_holder
                                });
    
                                utility.add("UIPadding", actual_title, { PaddingTop = dim(0, 5) });
                            
                                utility.new("TextLabel", {
                                    FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                                    TextColor3 = rgb(151, 151, 151);
                                    BorderColor3 = rgb(0, 0, 0);
                                    Text = dropdown.sub_name;
                                    Name = "sub_title";
                                    Size = dim2(0.5, 0, 0.5, 0);
                                    Position = dim2(0, 0, 0, 15);
                                    BackgroundTransparency = 1;
                                    TextXAlignment = Enum.TextXAlignment.Left;
                                    BorderSizePixel = 0;
                                    TextYAlignment = Enum.TextYAlignment.Bottom;
                                    TextSize = 14;
                                    BackgroundColor3 = rgb(255, 255, 255);
                                    Parent = title_holder
                                });
                            
                                local value_holder = utility.add("Frame", separator_holder, {
                                    Name = "value_holder",
                                    Position = dim2(1, -20, 0.5, 0),
                                    AnchorPoint = vec2(1, 0.5),
                                    Size = dim2(0, 168, 0, 22),
                                    BackgroundTransparency = 1,
                                    ZIndex = 2
                                });
                            
                                utility.add("UICorner", value_holder, { CornerRadius = dim(0, 4) });
                                utility.add("UIStroke", value_holder, { Color = rgb(214, 214, 214) });
                            
                                utility.add("ImageLabel", value_holder, {
                                    Name = "dropdown_icon",
                                    Image = "rbxassetid://107011646283263",
                                    Position = dim2(1, -4, 0.5, 0),
                                    AnchorPoint = vec2(1, 0.5),
                                    Size = dim2(0, 10, 0, 10),
                                    ScaleType = Enum.ScaleType.Fit,
                                    BorderSizePixel = 0,
                                    BackgroundColor3 = rgb(255, 255, 255)
                                });
                            
                                local options = utility.add("TextLabel", value_holder, {
                                    Name = "Options",
                                    FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal),
                                    TextColor3 = rgb(95, 95, 95),
                                    BorderColor3 = rgb(0, 0, 0),
                                    Text = "none",
                                    Size = dim2(1, -16, 1, 0),
                                    TextXAlignment = Enum.TextXAlignment.Left,
                                    ClipsDescendants = true,
                                    BorderSizePixel = 0,
                                    TextSize = 14,
                                    BackgroundColor3 = rgb(255, 255, 255)
                                })
                                do
                                    utility.add("UICorner", options, { CornerRadius = dim(0, 4) });
                                    utility.add("UIPadding", options, { PaddingTop = dim(0, 1), PaddingLeft = dim(0, 4) });
                                    utility.add("UIGradient", options, { Transparency = numseq{ numkey(0, 0), numkey(1, 0.13749998807907104) } });
                                end;
    
                                local actual_contents = utility.new("ScrollingFrame", {
                                    Name = "\0",
                                    Parent = value_holder,
                                    ScrollBarImageColor3 = rgb(0, 0, 0),
                                    BorderColor3 = rgb(0, 0, 0),
                                    Position = dim2(0, 0, 0, 22),
                                    Size = dim2(1, 0, 0, 78),
                                    ZIndex = 3,
                                    Visible = false,
                                    BorderSizePixel = 0,
                                    BackgroundColor3 = rgb(255, 255, 255),
                                    CanvasSize = dim2(0, 0, 0, 0),
                                    AutomaticCanvasSize = Enum.AutomaticSize.Y,
                                    ScrollingDirection = Enum.ScrollingDirection.Y,
                                    ClipsDescendants = true,
                                    ScrollBarThickness = 0
                                });
    
                                do
                                    utility.add("UICorner", actual_contents, { CornerRadius = dim(0, 4) });
                                    utility.add("UIStroke", actual_contents, { Color = rgb(214, 214, 214) });
                                    utility.add("UIListLayout", actual_contents, { SortOrder = Enum.SortOrder.LayoutOrder, Padding = dim(0, 1) });
                                    --utility.add("UIPadding", actual_contents, { PaddingLeft = dim(0, 12), PaddingRight = dim(0, 12) });
                                end;
                            
                                utility.handle_click(value_holder, function()
                                    actual_contents.Visible = not actual_contents.Visible;
                                end);
                            
                                local function update()
                                    options.Text = #dropdown.selected_options == 0 and "none" or table.concat(dropdown.selected_options, ", ");
                                end;
                            
                                function dropdown:set_selected(new_selected)
                                    self.selected_options = new_selected or {};
                                    for _, inst in ipairs(self.option_insts) do
                                        inst.TextColor3 = table.find(self.selected_options, inst.Text) and rgb(23, 134, 248) or rgb(95, 95, 95);
                                    end;
                                    update();
                                    self.callback(self.selected_options);
                                end;
                            
                                function dropdown:Set(new_selected)
                                    self:set_selected(new_selected);
                                end;
                            
                                function dropdown:SetOptions(new_options)
                                    self.options = new_options or {};
                                    self.selected_options = {};
                            
                                    for _, inst in ipairs(self.option_insts) do
                                        if inst and inst.Destroy then inst:Destroy(); end;
                                    end;
    
                                    table.clear(self.option_insts);
                            
                                    for _, opt in ipairs(self.options) do
                                        local inst = utility.new("TextLabel", {
                                            Parent = actual_contents,
                                            Text = opt,
                                            Size = dim2(1, 0, 0, 22),
                                            TextSize = 14,
                                            FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal),
                                            TextColor3 = rgb(95, 95, 95),
                                            TextXAlignment = Enum.TextXAlignment.Center,
                                            BackgroundColor3 = rgb(255, 255, 255),
                                            BackgroundTransparency = 0,
                                            BorderSizePixel = 0
                                        });
    
                                        do
                                            
                                            local sep = utility.new("Frame", {
                                                Parent = inst,
                                                Position = dim2(0, 0, 1, 0),
                                                Size = dim2(1, 0, 0, 1),
                                                BackgroundColor3 = rgb(214, 214, 214),
                                                BorderSizePixel = 0
                                            });
                                            utility.add("UIGradient", sep, {
                                                Transparency = numseq {
                                                    numkey(0, 1),
                                                    numkey(0.5, 0),
                                                    numkey(1, 1)
                                                }
                                            });
                                            utility.add("UIPadding", inst, { PaddingRight = dim(0, 4), PaddingLeft = dim(0, 4) });
                                            utility.add("UICorner", inst, { CornerRadius = dim(0, 4) });
                                            utility.add("UIGradient", inst, {
                                                Transparency = numseq {
                                                    numkey(0, 0),
                                                    numkey(1, 0.1375)
                                                }
                                            });
    
                                            utility.handle_click(inst, function()
                                                local val = inst.Text;
                                                local idx = table.find(self.selected_options, val);
                                                if idx then
                                                    table.remove(self.selected_options, idx);
                                                elseif #self.selected_options < self.max then
                                                    table.insert(self.selected_options, val);
                                                end;
                                                self:set_selected(self.selected_options);
                                            end);
                                        end;
    
                                        table.insert(self.option_insts, inst);
                                    end;
                            
                                    update();
                                end;
                            
                                dropdown:SetOptions(dropdown.options);
                            
                                return dropdown;
                            end;
                            function group_box.toggle(params)
                                params = params or {};
                            
                                local toggle = {
                                    name = params.Name or params.name or 'Title';
                                    sub_name = params.SubName or params.sub_name or 'Sub-Title';
                                    flag = params.Flag or params.flag or math.random(1, math.random(1, 1000));
                                    default = params.Default or params.default or false;
                                    state = params.State or params.state or params.Default or params.default or false;
                                    callback = params.Callback or params.callback or function() end;
                                    toggled = false;
                                    pickers = 0;
                                };
    
                                library.objects[toggle.flag] = toggle;
                            
                                local separator_holder = utility.new("Frame", {
                                    Parent = SectionContainer;
                                    BackgroundTransparency = 1;
                                    Name = "\0";
                                    BorderColor3 = rgb(0, 0, 0);
                                    Size = dim2(0, 478, 0, 45);
                                    BorderSizePixel = 0;
                                    BackgroundColor3 = rgb(100, 100, 100);
                                });
                            
                                local title_holder = utility.new("Frame", {
                                    BorderColor3 = rgb(0, 0, 0);
                                    Parent = separator_holder;
                                    AnchorPoint = vec2(0, 0);
                                    Name = "\0";
                                    BackgroundTransparency = 1;
                                    Position = dim2(0.023, 0, 0, 0);
                                    Size = dim2(0, 228, 0, 42);
                                    BorderSizePixel = 0;
                                    AutomaticSize = Enum.AutomaticSize.Y;
                                });
                            
                                local actual_title = utility.new("TextLabel", {
                                    FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
                                    TextColor3 = rgb(82, 82, 82);
                                    BorderColor3 = rgb(0, 0, 0);
                                    Text = toggle.name;
                                    Size = dim2(0.5, 0, 0.5, 0);
                                    AnchorPoint = vec2(0, 0.5);
                                    Position = dim2(0, 0, 0.5, -10);
                                    BackgroundTransparency = 1;
                                    TextXAlignment = Enum.TextXAlignment.Left;
                                    BorderSizePixel = 0;
                                    TextYAlignment = Enum.TextYAlignment.Top;
                                    TextSize = 14;
                                    BackgroundColor3 = rgb(255, 255, 255);
                                    Parent = title_holder;
                                });
                            
                                utility.add("UIPadding", actual_title, { PaddingTop = dim(0, 5) });
                            
                                local sub_title = utility.new("TextLabel", {
                                    FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                                    TextColor3 = rgb(151, 151, 151);
                                    BorderColor3 = rgb(0, 0, 0);
                                    Text = toggle.sub_name;
                                    Name = "sub_title";
                                    Size = dim2(0.5, 0, 0.5, 0);
                                    Position = dim2(0, 0, 0, 15);
                                    BackgroundTransparency = 1;
                                    TextXAlignment = Enum.TextXAlignment.Left;
                                    BorderSizePixel = 0;
                                    TextYAlignment = Enum.TextYAlignment.Bottom;
                                    TextSize = 14;
                                    BackgroundColor3 = rgb(255, 255, 255);
                                    Parent = title_holder;
                                });
                            
                                utility.add("UIPadding", sub_title, { PaddingTop = dim(0, 5) });
                            
                                utility.add("UICorner", separator_holder, { CornerRadius = dim(0, 4) });
                            
                                local actual_toggle = utility.new("Frame", {
                                    AnchorPoint = vec2(1, 0.5);
                                    Name = "\0";
                                    Position = dim2(1, -20, 0.5, 0);
                                    BorderColor3 = rgb(0, 0, 0);
                                    Size = dim2(0, 35, 0, 18);
                                    BorderSizePixel = 0;
                                    BackgroundColor3 = rgb(23, 134, 248);
                                    Parent = separator_holder;
                                });
                            
                                utility.add("UIPadding", actual_toggle, {
                                    PaddingRight = dim(0, 2);
                                    PaddingLeft = dim(0, 2);
                                });
                            
                                utility.add("UICorner", actual_toggle, { CornerRadius = dim(0, 10) });
                            
                                local layout = utility.add("UIListLayout", actual_toggle, {
                                    VerticalAlignment = Enum.VerticalAlignment.Center;
                                    SortOrder = Enum.SortOrder.LayoutOrder;
                                    HorizontalAlignment = Enum.HorizontalAlignment.Right;
                                    FillDirection = Enum.FillDirection.Horizontal;
                                });
                            
                                local circle = utility.new("Frame", {
                                    Name = "\0";
                                    BorderColor3 = rgb(0, 0, 0);
                                    Size = dim2(0, 14, 0, 14);
                                    BorderSizePixel = 0;
                                    BackgroundColor3 = rgb(255, 255, 255);
                                    Parent = actual_toggle;
                                });
                            
                                utility.add("UICorner", circle, { CornerRadius = dim(0, 10) });
                            
                                utility.new("Frame", {
                                    Parent = separator_holder;
                                    Name = "\0";
                                    Position = dim2(0.0235, 0, 1, 0);
                                    BorderColor3 = rgb(0, 0, 0);
                                    Size = dim2(0.954, 0, 0, 1);
                                    BorderSizePixel = 0;
                                    BackgroundColor3 = rgb(214, 214, 214);
                                });
                            
                                local function set_state(v)
                                    toggle.state = v;
                                    library.flags[toggle.flag] = v;
                                    actual_toggle.BackgroundColor3 = v and rgb(23, 134, 248) or rgb(231, 231, 231);
                                    layout.HorizontalAlignment = v and Enum.HorizontalAlignment.Right or Enum.HorizontalAlignment.Left;
                                    toggle.callback(v);
                                end;
                            
                                set_state(toggle.state);
                            
                                utility.handle_click(actual_toggle, function()
                                    set_state(not toggle.state);
                                end);
                            
                                function toggle:Set(v)
                                    toggle.state = v;
                                    library.flags[toggle.flag] = v;
                                    actual_toggle.BackgroundColor3 = v and rgb(23, 134, 248) or rgb(231, 231, 231);
                                    layout.HorizontalAlignment = v and Enum.HorizontalAlignment.Right or Enum.HorizontalAlignment.Left;
                                    toggle.callback(v);
                                end;
    
                                function toggle.keybind(params)
                                    params = params or {};
                                
                                    local keybind = {
                                        name = params.name or params.Name or 'keybind';
                                        flag = params.flag or params.Flag or math.random(1000);
                                        key = params.default or params.Default or nil;
                                        callback = params.callback or params.Callback or function() end;
                                        toggled = false;
                                    };
    
                                    library.objects[keybind.flag] = keybind;
                                
                                    local value_holder = utility.new("Frame", {
                                        BorderColor3 = rgb(0, 0, 0);
                                        AnchorPoint = vec2(1, 0.5);
                                        BackgroundTransparency = 1;
                                        Position = dim2(1, -65, 0.5, 0);
                                        Name = "ValueHolder";
                                        Size = dim2(0, 35, 0, 18);
                                        BorderSizePixel = 0;
                                        BackgroundColor3 = rgb(23, 134, 248);
                                        Parent = separator_holder;
                                    });
                                
                                    utility.add("UICorner", value_holder, {
                                        CornerRadius = dim(0, 4);
                                    });
                                
                                    utility.add("UIStroke", value_holder, {
                                        Color = rgb(214, 214, 214);
                                    });
                                
                                    local value = utility.new("TextLabel", {
                                        FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
                                        TextColor3 = rgb(95, 95, 95);
                                        BorderColor3 = rgb(0, 0, 0);
                                        Text = keybind.key or "None";
                                        AnchorPoint = vec2(0.5, 0.5);
                                        Name = "Value";
                                        BackgroundTransparency = 1;
                                        Position = dim2(0.5, 0, 0.5, 0);
                                        Size = dim2(1, 0, 1, 0);
                                        BorderSizePixel = 0;
                                        TextSize = 14;
                                        BackgroundColor3 = rgb(255, 255, 255);
                                        Parent = value_holder;
                                    });
                                
                                    local key_set = keybind.key ~= nil;
                                
                                    local function set_state(v)
                                        keybind.toggled = v;
                                        library.flags[keybind.flag] = { state = v, key = keybind.key };
                                        keybind.callback(v);
                                    end;
                                
                                    game:GetService("UserInputService").InputBegan:Connect(function(input, game_processed)
                                        if game_processed then return end;
                                        if input.UserInputType == Enum.UserInputType.Keyboard then
                                            if keybind.key and input.KeyCode.Name == keybind.key then
                                                keybind.toggled = not keybind.toggled;
                                                set_state(keybind.toggled);
                                            elseif not key_set then
                                                keybind.key = input.KeyCode.Name;
                                                value.Text = keybind.key;
                                                keybind.toggled = true;
                                                set_state(true);
                                                key_set = true;
                                            end;
                                        end;
                                    end);
                                
                                    utility.handle_click(value_holder, function()
                                        if keybind.toggled then
                                            keybind.toggled = false;
                                            set_state(false);
                                        else
                                            key_set = false;
                                            keybind.key = nil;
                                            value.Text = "None";
                                            set_state(false);
                                        end;
                                    end);
                                
                                    function keybind:Set(new_state, new_key)
                                        keybind.toggled = new_state;
                                        keybind.key = new_key or keybind.key;
                                        library.flags[keybind.flag] = { state = keybind.toggled, key = keybind.key };
                                        value.Text = keybind.key or "None";
                                        set_state(keybind.toggled);
                                    end;
                                
                                    return keybind;
                                end;
                                
                            return toggle
                        end
    
                        function group_box.slider(params)
                            if not params then params = {} end;
                            
                            local slider = {
                                name = params.Name or params.name or 'slider';
                                min = params.Min or params.min or 1;
                                max = params.Max or params.max or 10;
                                decimals = params.Decimals or params.decimals or 1;
                                suffix = params.Suffix or params.suffix or 'ms',
                                state = params.Default or params.default or 5;
                                flag = params.Flag or params.flag or math.random(1, math.random(1, 1000));
                                callback = params.Callback or params.callback or function() end;
                            };
                            
                            library.objects[slider.flag] = slider;
                        
                            local separator_holder = utility.new("Frame", {
                                Parent = SectionContainer;
                                BackgroundTransparency = 1;
                                Name = "\0";
                                BorderColor3 = rgb(0, 0, 0);
                                Size = dim2(0, 478, 0, 45);
                                BorderSizePixel = 0;
                                BackgroundColor3 = rgb(100, 100, 100);
                            });
                        
                            local title_holder = utility.new("Frame", {
                                BorderColor3 = rgb(0, 0, 0);
                                Parent = separator_holder;
                                AnchorPoint = vec2(0, 0);
                                Name = "\0";
                                BackgroundTransparency = 1;
                                Position = dim2(0.023, 0, 0, 0);
                                Size = dim2(0, 228, 0, 42);
                                BorderSizePixel = 0;
                                AutomaticSize = Enum.AutomaticSize.Y;
                            });
                        
                            local actual_title = utility.new("TextLabel", {
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
                                TextColor3 = rgb(82, 82, 82);
                                BorderColor3 = rgb(0, 0, 0);
                                Text = params.name;
                                Size = dim2(0.5, 0, 0.5, 0);
                                AnchorPoint = vec2(0, 0.5);
                                Position = dim2(0, 0, 0.5, -10);
                                BackgroundTransparency = 1;
                                TextXAlignment = Enum.TextXAlignment.Left;
                                BorderSizePixel = 0;
                                TextYAlignment = Enum.TextYAlignment.Top;
                                TextSize = 14;
                                BackgroundColor3 = rgb(255, 255, 255);
                                Parent = title_holder;
                            });
                        
                            utility.add("UIPadding", actual_title, {
                                PaddingTop = dim(0, 5);
                            });
                        
                            utility.new("TextLabel", {
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                                TextColor3 = rgb(151, 151, 151);
                                BorderColor3 = rgb(0, 0, 0);
                                Text = params.sub_name;
                                Name = "sub_title";
                                Size = dim2(0.5, 0, 0.5, 0);
                                Position = dim2(0, 0, 0, 15);
                                BackgroundTransparency = 1;
                                TextXAlignment = Enum.TextXAlignment.Left;
                                BorderSizePixel = 0;
                                TextYAlignment = Enum.TextYAlignment.Bottom;
                                TextSize = 14;
                                BackgroundColor3 = rgb(255, 255, 255);
                                Parent = title_holder;
                            });
                        
                            local value = utility.new("TextLabel", {
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal),
                                TextColor3 = rgb(151, 151, 151),
                                BorderColor3 = rgb(0, 0, 0),
                                AnchorPoint = vec2(1, 0.5),
                                Name = "\0",
                                Text = slider.suffix,
                                BackgroundTransparency = 1,
                                Position = dim2(1, -20, 0.5, -1),
                                Size = dim2(0, 35, 0, 18),
                                BorderSizePixel = 0,
                                TextSize = 14,
                                BackgroundColor3 = rgb(255, 255, 255),
                                Parent = separator_holder;
                            });
                        
                            local value_holder = utility.new("Frame", {
                                BorderColor3 = rgb(0, 0, 0),
                                AnchorPoint = vec2(1, 0.5),
                                BackgroundTransparency = 1,
                                Position = dim2(1, -75, 0.5, 0),
                                Name = "ValueHolder",
                                Size = dim2(0, 40, 0, 18),
                                BorderSizePixel = 0,
                                BackgroundColor3 = rgb(23, 134, 248),
                                Parent = separator_holder;
                            });
                        
                            utility.add("UICorner", value_holder, {
                                CornerRadius = dim(0, 4);
                            });
                        
                            utility.add("UIStroke", value_holder, {
                                Color = rgb(214, 214, 214);
                            });
                        
                            local value_label = utility.new("TextLabel", {
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
                                TextColor3 = rgb(95, 95, 95);
                                BorderColor3 = rgb(0, 0, 0);
                                Text = "";
                                AnchorPoint = vec2(0.5, 0.5);
                                Name = "Value";
                                BackgroundTransparency = 1;
                                Position = dim2(0.5, 0, 0.5, 0);
                                Size = dim2(1, 0, 1, 0);
                                BorderSizePixel = 0;
                                TextSize = 14;
                                BackgroundColor3 = rgb(255, 255, 255);
                                Parent = value_holder;
                            });
                            utility.add("UICorner", value_label, {
                                CornerRadius = dim(0, 4);
                            });
                            local left = utility.new("ImageLabel", {
                                ScaleType = Enum.ScaleType.Fit;
                                BorderColor3 = rgb(0, 0, 0);
                                Name = "Left";
                                Size = dim2(0, 14, 0, 14);
                                AnchorPoint = vec2(0.5, 0.5);
                                Image = "rbxassetid://71232767826177";
                                BackgroundTransparency = 1;
                                Position = dim2(0.5, -30, 0.5, 0);
                                Rotation = -90;
                                BorderSizePixel = 0;
                                BackgroundColor3 = rgb(255, 255, 255);
                                Parent = value_holder;
                            });
                        
                            local right = utility.new("ImageLabel", {
                                ScaleType = Enum.ScaleType.Fit;
                                BorderColor3 = rgb(0, 0, 0);
                                Name = "Right";
                                Size = dim2(0, 14, 0, 14);
                                AnchorPoint = vec2(0.5, 0.5);
                                Image = "rbxassetid://71232767826177";
                                BackgroundTransparency = 1;
                                Position = dim2(0.5, 30, 0.5, 0);
                                Rotation = 90;
                                BorderSizePixel = 0;
                                BackgroundColor3 = rgb(255, 255, 255);
                                Parent = value_holder;
                            });
                        
                            local function clamp(x, min, max)
                                return math.max(min, math.min(max, x));
                            end;
                        
                            local function round(n, decimals)
                                local factor = 10 ^ decimals;
                                return math.floor(n * factor + 0.5) / factor;
                            end;
                        
                            local function update()
                                local value = round(slider.state, slider.decimals);
                                value_label.Text = tostring(value);
                                slider.state = value;
                                library.flags[slider.flag] = value;
                                slider.callback(value);
                            end;
                        
                            utility.handle_click(left, function()
                                slider.state = clamp(round(slider.state - (1 / (10 ^ slider.decimals)), slider.decimals), slider.min, slider.max);
                                update();
                            end);
                        
                            utility.handle_click(right, function()
                                slider.state = clamp(round(slider.state + (1 / (10 ^ slider.decimals)), slider.decimals), slider.min, slider.max);
                                update();
                            end);
                        
                            update();
                        
                            function slider:Set(val)
                                slider.state = clamp(round(val, slider.decimals), slider.min, slider.max);
                                update();
                            end
                        
                            library.flags[slider.flag] = slider.state;
                        
                            return slider;
                        end;                    
    
                        function group_box.keybind(params)
                            
                            local keybind = {
                                Name = params.Name or "keybind";
                                Flag = tostring(params.Flag or math.random(1000));
                                Key = params.Default or nil;
                                Callback = params.Callback or function() end;
                                Toggled = false;
                                Mode = (params.Mode == "Toggle") and "Toggle" or "Hold";
                            };
                        
                            library.objects[keybind.Flag] = keybind;
                            local key_set = keybind.Key ~= nil;
                        
                            local function update_state(state)
                                keybind.Toggled = state;
                                library.flags[keybind.Flag] = { state = keybind.Toggled, key = keybind.Key };
                                keybind.Callback(keybind.Key, state);
                            end;
                        
                            local separator_holder = utility.new("Frame", {
                                Parent = SectionContainer;
                                Size = dim2(0, 478, 0, 45);
                                BackgroundTransparency = 1;
                                BorderSizePixel = 0;
                                BackgroundColor3 = rgb(100, 100, 100);
                            });
                        
                            utility.add("UICorner", separator_holder, { CornerRadius = dim(0, 4) });
                        
                            local title_holder = utility.new("Frame", {
                                Parent = separator_holder;
                                Size = dim2(0, 228, 0, 42);
                                Position = dim2(0.023, 0, 0, 0);
                                AnchorPoint = vec2(0, 0);
                                BackgroundTransparency = 1;
                                BorderSizePixel = 0;
                                AutomaticSize = Enum.AutomaticSize.Y;
                            });
                        
                            local actual_title = utility.new("TextLabel", {
                                Parent = title_holder;
                                Text = params.Name;
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
                                TextColor3 = rgb(82, 82, 82);
                                Size = dim2(0.5, 0, 0.5, 0);
                                Position = dim2(0, 0, 0.5, -10);
                                AnchorPoint = vec2(0, 0.5);
                                BackgroundTransparency = 1;
                                TextSize = 14;
                                TextXAlignment = Enum.TextXAlignment.Left;
                                TextYAlignment = Enum.TextYAlignment.Top;
                                BorderSizePixel = 0;
                            });
                        
                            utility.add("UIPadding", actual_title, { PaddingTop = dim(0, 5) });
                        
                            local sub_title = utility.new("TextLabel", {
                                Parent = title_holder;
                                Text = params.sub_name;
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                                TextColor3 = rgb(151, 151, 151);
                                Size = dim2(0.5, 0, 0.5, 0);
                                Position = dim2(0, 0, 0, 15);
                                AnchorPoint = vec2(0, 0);
                                BackgroundTransparency = 1;
                                TextSize = 14;
                                TextXAlignment = Enum.TextXAlignment.Left;
                                TextYAlignment = Enum.TextYAlignment.Bottom;
                                BorderSizePixel = 0;
                            });
                        
                            utility.add("UIPadding", sub_title, { PaddingTop = dim(0, 5) });
                        
                            local value_holder = utility.new("Frame", {
                                Parent = separator_holder;
                                Size = dim2(0, 35, 0, 18);
                                Position = dim2(1, -20, 0.5, 0);
                                AnchorPoint = vec2(1, 0.5);
                                BackgroundTransparency = 1;
                                BackgroundColor3 = rgb(23, 134, 248);
                                Name = "ValueHolder";
                            });
                        
                            utility.add("UICorner", value_holder, { CornerRadius = dim(0, 4) });
                            utility.add("UIStroke", value_holder, { Color = rgb(214, 214, 214) });
                        
                            local value = utility.new("TextLabel", {
                                Parent = value_holder;
                                Text = keybind.Key or "None";
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Medium, Enum.FontStyle.Normal);
                                TextColor3 = rgb(95, 95, 95);
                                Size = dim2(1, 0, 1, 0);
                                Position = dim2(0.5, 0, 0.5, 0);
                                AnchorPoint = vec2(0.5, 0.5);
                                TextSize = 14;
                                BackgroundTransparency = 1;
                                BorderSizePixel = 0;
                            });
                        
                            utility.new("Frame", {
                                Parent = separator_holder;
                                Position = dim2(0.0235, 0, 1, 0);
                                Size = dim2(0.954, 0, 0, 1);
                                BorderSizePixel = 0;
                                BackgroundColor3 = rgb(214, 214, 214);
                                BorderColor3 = rgb(0, 0, 0);
                            });
    
                            game:GetService("UserInputService").InputBegan:Connect(function(input, game_processed)
                                if game_processed then return end;
                        
                                if input.UserInputType == Enum.UserInputType.Keyboard then
                                    if keybind.Key and input.KeyCode.Name == keybind.Key then
                                        if keybind.Mode == "Toggle" then
                                            update_state(not keybind.Toggled);
                                        else
                                            update_state(true);
                                        end;
                                    elseif not key_set then
                                        keybind.Key = input.KeyCode.Name;
                                        value.Text = keybind.Key;
                                        key_set = true;
                        
                                        if keybind.Mode == "Toggle" then
                                            update_state(not keybind.Toggled);
                                        else
                                            update_state(true);
                                        end;
                                    end;
                                end;
                            end);
                        
                            game:GetService("UserInputService").InputEnded:Connect(function(input)
                                if input.UserInputType == Enum.UserInputType.Keyboard and input.KeyCode.Name == keybind.Key then
                                    if keybind.Mode == "Hold" then
                                        update_state(false);
                                    end;
                                end;
                            end);
                        
                            utility.handle_click(value_holder, function()
                                keybind.Key = nil;
                                value.Text = "None";
                                key_set = false;
                                update_state(false);
                            end);
                        
                            return keybind;
                        end;
    
                        function group_box.input(params)
                            params = params or {};
                        
                            local input = {
                                Title = params.Title or params.title or "Title";
                                Flag = params.flag or params.Flag or math.random(1, math.random(1, 1000));
                                Callback = params.Callback or params.callback or function() end;
                            };
                        
                            library.objects[input.Flag] = input;
                        
                            local separator_holder = utility.new("Frame", {
                                Parent = SectionContainer;
                                Name = "\0";
                                Size = dim2(0, 478, 0, 30);
                                BorderSizePixel = 0;
                                BackgroundTransparency = 1;
                                BorderColor3 = rgb(0, 0, 0);
                                BackgroundColor3 = rgb(100, 100, 100);
                            });
                        
                            do utility.add("UICorner", separator_holder, { CornerRadius = dim(0, 4) }) end;
                        
                            local title_holder = utility.new("Frame", {
                                Parent = separator_holder;
                                Name = "\0";
                                Size = dim2(0, 228, 0, 21);
                                Position = dim2(0.023, 0, 0.5, 0);
                                AnchorPoint = vec2(0, 0.5);
                                BorderSizePixel = 0;
                                AutomaticSize = Enum.AutomaticSize.Y;
                                BackgroundTransparency = 1;
                                BorderColor3 = rgb(0, 0, 0);
                            });
                        
                            do utility.new("TextLabel", {
                                Parent = title_holder;
                                Name = "\0";
                                Size = dim2(1, 0, 1, 0);
                                Position = dim2(0, 0, 0.5, 0);
                                AnchorPoint = vec2(0, 0.5);
                                BackgroundTransparency = 1;
                                BorderSizePixel = 0;
                                Text = input.Title;
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                                TextSize = 14;
                                TextColor3 = rgb(82, 82, 82);
                                TextXAlignment = Enum.TextXAlignment.Left;
                                BackgroundColor3 = rgb(255, 255, 255);
                                BorderColor3 = rgb(0, 0, 0);
                                Active = true;
                            }) end;
                        
                            local actual_side_holder = utility.new("Frame", {
                                Parent = separator_holder;
                                Name = "\0";
                                Size = dim2(0, 40, 0, 18);
                                Position = dim2(1, -20, 0.5, 0);
                                AnchorPoint = vec2(1, 0.5);
                                BackgroundTransparency = 1;
                                BorderSizePixel = 0;
                                BorderColor3 = rgb(0, 0, 0);
                            });
                        
                            local text_box = utility.new("TextBox", {
                                Parent = actual_side_holder;
                                Size = dim2(1, 0, 1, 0);
                                Position = dim2(0.5, 0, 0.5, 0);
                                AnchorPoint = vec2(0.5, 0.5);
                                BorderSizePixel = 0;
                                FontFace = Font.new("rbxassetid://12187365364", Enum.FontWeight.Regular, Enum.FontStyle.Normal);
                                TextSize = 14;
                                TextColor3 = rgb(151, 151, 151);
                                BackgroundColor3 = rgb(255, 255, 255);
                                PlaceholderText = "Text";
                                ClearTextOnFocus = false;
                                Text = "";
                                TextXAlignment = Enum.TextXAlignment.Right,
                                BorderColor3 = rgb(0, 0, 0);
                            });
                        
                            do utility.new("Frame", {
                                Parent = separator_holder;
                                Name = "\0";
                                Position = dim2(0.0235, 0, 1, 0);
                                Size = dim2(0.954, 0, 0, 1);
                                BorderSizePixel = 0;
                                BackgroundColor3 = rgb(214, 214, 214);
                                BorderColor3 = rgb(0, 0, 0);
                            }) end;
                        
                            library.flags[input.Flag] = text_box.Text;
                        
                            text_box.FocusLost:Connect(function()
                                local new_val = text_box.Text;
                                library.flags[input.Flag] = new_val;
                                input.Callback(new_val);
                            end);
                        
                            function input:Set(new_text)
                                text_box.Text = new_text;
                                library.flags[input.Flag] = new_text;
                                input.Callback(new_text);
                            end;
                        
                            input.instance = text_box;
                            return input;
                        end
                
                        return group_box
                    end
                
                    return tab
                end
    
                return section
            end
            return window;
        end
    end
 
    local window = library.window({title = 'PuppyWare', sub_title = 'Final'})


    local combat_sec = window.section({ Name = "Combat" })
    local rage_tab = combat_sec.tab({ Name = "Rage Bot" })
    local misc_tab = combat_sec.tab({ Name = "Misc" })
    local hvh_sec = window.section({ Name = "HvH" })
    local hvh_tab = hvh_sec.tab({ Name = "Anti-Aim" })
    local visuals_sec = window.section({ Name = "Visuals" })
    local target_tab = visuals_sec.tab({ Name = "Target" })
     local esp_tab = visuals_sec.tab({ Name = "ESP" })
    local crosshair_tab = visuals_sec.tab({ Name = "Crosshair" })
     local rage_box = rage_tab.group_box()
    local rage_options = rage_tab.group_box()
    local misc_box = misc_tab.group_box()
    local hvh_box = hvh_tab.group_box()
    local target_box = target_tab.group_box()
 
    local crosshair_box = crosshair_tab.group_box()
    local crosshair_settings = crosshair_tab.group_box()
    local effects_box = crosshair_tab.group_box()
    local esp_box = esp_tab.group_box()
    local esp_features = esp_tab.group_box()
 
    local config_files = get_config_files()
    
    local config_section = window.section({ Name = "Config" })
    local config_tab = config_section.tab({ Name = "Config" })
    local config_box = config_tab.group_box()
     
 
    rage_box.toggle({
        name = "Enabled",
        sub_name = "Toggle rage bot",
        flag = "rage_enabled",
        Default = PuppyWare.Combat.rage_bot.Enabled,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Enabled = state
        end
    }).keybind({
        Name = "Rage Key",
        Flag = "rage_key",
        Default = PuppyWare.Combat.rage_bot.Keybind,
        UseKey = true
    })
    
    rage_box.input({
        Title = "Prediction",
        Flag = "prediction",
        Callback = function(v)
            PuppyWare.Combat.rage_bot.Prediction = tonumber(v) or 0
        end
    })
    
    rage_options.toggle({
        name = "Bullet Manipulation",
        sub_name = "Manipulate bullets",
        flag = "bullet_manip",
        Default = PuppyWare.Combat.rage_bot.Rage.Bullet_Manipulation,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Bullet_Manipulation = state
        end
    })
    
    rage_options.toggle({
        name = "Wallbang",
        sub_name = "Shoot through walls",
        flag = "wallbang",
        Default = PuppyWare.Combat.rage_bot.Rage.Wallbang,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Wallbang = state
        end
    })
    
    rage_options.toggle({
        name = "Kill Aura",
        sub_name = "Auto kill nearby players",
        flag = "kill_aura",
        Default = PuppyWare.Combat.rage_bot.Rage.Kill_Aura,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Kill_Aura = state
        end
    })
    
    rage_options.toggle({
        name = "Auto Shoot",
        sub_name = "Automatically shoot",
        flag = "auto_shoot",
        Default = PuppyWare.Combat.rage_bot.Rage.Auto_Shoot,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Auto_Shoot = state
        end
    })
    
    rage_options.toggle({
        name = "Auto Stomp",
        sub_name = "Auto stomp downed players",
        flag = "auto_stomp",
        Default = PuppyWare.Combat.rage_bot.Rage.Auto_Stomp,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Auto_Stomp = state
        end
    })
    
    rage_options.toggle({
        name = "All Guns",
        sub_name = "Enable on all weapons",
        flag = "all_guns",
        Default = PuppyWare.Combat.rage_bot.Rage.All_Guns,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.All_Guns = state
        end
    }).keybind({
        Name = "All Guns Key",
        Flag = "all_guns_key",
        Default = PuppyWare.Combat.rage_bot.Rage.All_Guns_Key,
        UseKey = true
    })
    
    rage_options.toggle({
        name = "Anti Stomp",
        sub_name = "Prevent being stomped",
        flag = "anti_stomp",
        Default = PuppyWare.Combat.rage_bot.Rage.Anti_Stomp,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Anti_Stomp = state
        end
    })
    
    rage_options.toggle({
        name = "Flashback",
        sub_name = "Teleport to previous position",
        flag = "flashback",
        Default = PuppyWare.Combat.rage_bot.Rage.Flashback,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Flashback = state
        end
    })
    
    rage_options.toggle({
        name = "Auto Reload",
        sub_name = "Reload automatically",
        flag = "auto_reload",
        Default = PuppyWare.Combat.rage_bot.Rage.Auto_Reload,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Rage.Auto_Reload = state
        end
    })
    
    misc_box.toggle({
        name = "Auto Select",
        sub_name = "Auto select targets",
        flag = "auto_select",
        Default = PuppyWare.Combat.rage_bot.Misc.Auto_Select,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Misc.Auto_Select = state
        end
    })

    misc_box.toggle({
        name = "No Slow Down",
        sub_name = "Gets Rid Of Slow Cooldown",
        flag = "NoSlowDown",
        Default = PuppyWare.Combat.rage_bot.Misc.NoSlowDown,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Misc.NoSlowDown = state
        end
    })

    misc_box.toggle({
        name = "No Jump CoolDown",
        sub_name = "Gets Rid Of Jump Cooldown",
        flag = "NoSlowDown",
        Default = PuppyWare.Combat.rage_bot.Misc.NoJumpCoolDown,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Misc.NoJumpCoolDown = state
        end
    })

    misc_box.toggle({
        name = "Bunny Hop",
        sub_name = "Jumps For You Like A Bunny",
        flag = "BHop",
        Default = PuppyWare.Combat.rage_bot.Misc.BunnyHop,
        callback = function(state)
            PuppyWare.Combat.rage_bot.Misc.BunnyHop = state
        end
    })
    misc_box.toggle({
        name = "Speed Enabled",
        sub_name = "Enable speed hack",
        flag = "speed_enabled",
        Default = PuppyWare.Misc.player.SpeedEnabled,
        callback = function(state)
            PuppyWare.Misc.player.SpeedEnabled = state
        end
    }).keybind({
        Name = "Speed Key",
        Flag = "speed_key",
        Default = PuppyWare.Misc.player.SpeedKey,
        UseKey = true
    })
    
    misc_box.slider({
        name = "Speed",
        min = 16,
        max = 150,
        sub_name = 'Player speed',
        decimals = 0,
        default = PuppyWare.Misc.player.Speed,
        suffix = "studs/s",
        flag = "speed_value",
        callback = function(val)
            PuppyWare.Misc.player.Speed = val
        end
    })
    
    misc_box.toggle({
        name = "Fly Enabled",
        sub_name = "Enable fly hack",
        flag = "fly_enabled",
        Default = PuppyWare.Misc.player.FlyEnabled,
        callback = function(state)
            PuppyWare.Misc.player.FlyEnabled = state
        end
    }).keybind({
        Name = "Fly Key",
        Flag = "fly_key",
        Default = PuppyWare.Misc.player.FlyKey,
        UseKey = true
    })
    
    misc_box.slider({
        name = "Fly Speed",
        min = 50,
        max = 1000,
        sub_name = 'Flying speed',
        decimals = 0,
        default = PuppyWare.Misc.player.FlySpeed,
        suffix = "studs/s",
        flag = "fly_speed",
        callback = function(val)
            PuppyWare.Misc.player.FlySpeed = val
        end
    })

    misc_box.toggle({
        name = "Auto Armor",
        sub_name = "Auto buy armor",
        flag = "auto_armor",
        Default = PuppyWare.Misc.player.AutoArmorEnabled,
        callback = function(state)
            PuppyWare.Misc.player.AutoArmorEnabled = state
            getgenv().autoArmorEnabled = state
        end
    })
    
    misc_box.slider({
        name = "Armor Threshold",
        min = 0,
        max = 100,
        sub_name = 'Auto buy when below',
        decimals = 0,
        default = PuppyWare.Misc.player.ArmorThreshold,
        suffix = "%",
        flag = "armor_threshold",
        callback = function(val)
            PuppyWare.Misc.player.ArmorThreshold = val
            getgenv().armorThreshold = val
        end
    })
    
    misc_box.toggle({
        name = "Auto Fire Armor",
        sub_name = "Auto buy fire armor",
        flag = "auto_farmor",
        Default = PuppyWare.Misc.player.AutoFArmorEnabled,
        callback = function(state)
            PuppyWare.Misc.player.AutoFArmorEnabled = state
            getgenv().autoFArmorEnabled = state
        end
    })
    
    misc_box.slider({
        name = "Fire Armor Threshold",
        min = 0,
        max = 100,
        sub_name = 'Auto buy when below',
        decimals = 0,
        default = PuppyWare.Misc.player.FArmorThreshold,
        suffix = "%",
        flag = "farmor_threshold",
        callback = function(val)
            PuppyWare.Misc.player.FArmorThreshold = val
            getgenv().fArmorThreshold = val
        end
    })
 
    hvh_box.toggle({
        name = "Server Desync",
        sub_name = "Enable server desynchronization",
        flag = "server_desync",
        Default = PuppyWare.HvH.Antis.ServerDesynchronization,
        callback = function(state)
            PuppyWare.HvH.Antis.ServerDesynchronization = state
        end
    }).keybind({
        Name = "Desync Key",
        Flag = "desync_key",
        Default = PuppyWare.HvH.Antis.Key,
        UseKey = true
    })
    
    local xdddd = hvh_box.dropdown({
        name = "Desync Mode",
        sub_name = 'Select the mode',
        flag = "diwnobabaprolol",
        max = 1,    
        Default = PuppyWare.HvH.Antis.Modes,
        callback = function(val)
            PuppyWare.HvH.Antis.Modes = val
        end;
    })
    
    xdddd:SetOptions({"Void", "Random"})
    esp_box.toggle({
        name = "FOV Visible",
        sub_name = "Show FOV circle",
        flag = "fov_visible",
        Default = PuppyWare.Visualization.Fov.Properties.Visible,
        callback = function(state)
            PuppyWare.Visualization.Fov.Properties.Visible = state
        end
    })
    
    esp_box.slider({
        name = "FOV Radius",
        min = 10,
        max = 500,
        sub_name = 'Circle size',
        decimals = 0,
        default = PuppyWare.Visualization.Fov.Properties.Radius,
        suffix = "px",
        flag = "fov_radius",
        callback = function(val)
            PuppyWare.Visualization.Fov.Properties.Radius = val
        end
    })
    
    esp_box.slider({
        name = "Transparency",
        min = 0,
        max = 1,
        sub_name = 'FOV circle transparency',
        decimals = 1,
        default = PuppyWare.Visualization.Fov.Properties.Transparency,
        flag = "fov_transparency",
        callback = function(val)
            PuppyWare.Visualization.Fov.Properties.Transparency = val
        end
    })
    
    crosshair_box.toggle({
        name = "Enabled",
        sub_name = "Show crosshair",
        flag = "crosshair_enabled",
        Default = PuppyWare.Visualization.Crosshair.Global.Enabled,
        callback = function(state)
            PuppyWare.Visualization.Crosshair.Global.Enabled = state
        end
    })
    
    crosshair_settings.slider({
        name = "Width",
        min = 0.5,
        max = 5,
        sub_name = 'Crosshair thickness',
        decimals = 1,
        default = PuppyWare.Visualization.Crosshair.Settings.Width,
        flag = "crosshair_width",
        callback = function(val)
            PuppyWare.Visualization.Crosshair.Settings.Width = val
        end
    })
    
    crosshair_settings.slider({
        name = "Length",
        min = 5,
        max = 30,
        sub_name = 'Crosshair length',
        decimals = 0,
        default = PuppyWare.Visualization.Crosshair.Settings.Length,
        flag = "crosshair_length",
        callback = function(val)
            PuppyWare.Visualization.Crosshair.Settings.Length = val
        end
    })
    
    crosshair_settings.slider({
        name = "Radius",
        min = 1,
        max = 30,
        sub_name = 'Crosshair gap',
        decimals = 0,
        default = PuppyWare.Visualization.Crosshair.Settings.Radius,
        flag = "crosshair_radius",
        callback = function(val)
            PuppyWare.Visualization.Crosshair.Settings.Radius = val
        end
    })
    
    effects_box.toggle({
        name = "Spin",
        sub_name = "Spinning crosshair",
        flag = "crosshair_spin",
        Default = PuppyWare.Visualization.Crosshair.Effects.Spin,
        callback = function(state)
            PuppyWare.Visualization.Crosshair.Effects.Spin = state
        end
    })
    
    effects_box.slider({
        name = "Speed",
        min = 50,
        max = 500,
        sub_name = 'Spin speed',
        decimals = 0,
        default = PuppyWare.Visualization.Crosshair.Effects.Speed,
        flag = "spin_speed",
        callback = function(val)
            PuppyWare.Visualization.Crosshair.Effects.Speed = val
        end
    })
    
    effects_box.toggle({
        name = "Animation",
        sub_name = "Animated crosshair",
        flag = "crosshair_animate",
        Default = PuppyWare.Visualization.Crosshair.Animate.Enabled,
        callback = function(state)
            PuppyWare.Visualization.Crosshair.Animate.Enabled = state
        end
    })
    
    effects_box.slider({
        name = "Animation Speed",
        min = 1,
        max = 10,
        sub_name = 'Animation speed',
        decimals = 1,
        default = PuppyWare.Visualization.Crosshair.Animate.Speed,
        flag = "anim_speed",
        callback = function(val)
            PuppyWare.Visualization.Crosshair.Animate.Speed = val
        end
    })
    
    esp_box.toggle({
        name = "ESP Enabled",
        sub_name = "Enable player ESP",
        flag = "esp_enabled",
        Default = PuppyWare.Visuals.player_esp.Enabled,
        callback = function(state)
            PuppyWare.Visuals.player_esp.Enabled = state
        end
    })
    
    esp_box.toggle({
        name = "Team Check",
        sub_name = "Don't ESP teammates",
        flag = "esp_teamcheck",
        Default = PuppyWare.Visuals.player_esp.Teamcheck,
        callback = function(state)
            PuppyWare.Visuals.player_esp.Teamcheck = state
        end
    })
    
    esp_box.slider({
        name = "ESP Distance",
        min = 1000,
        max = 100000,
        sub_name = 'Maximum distance',
        decimals = 0,
        default = PuppyWare.Visuals.player_esp.Distance_Check,
        suffix = "studs",
        flag = "esp_distance",
        callback = function(val)
            PuppyWare.Visuals.player_esp.Distance_Check = val
        end
    })
    
    esp_features.toggle({
        name = "Boxes",
        sub_name = "Show ESP boxes",
        flag = "esp_boxes",
        Default = PuppyWare.Visuals.player_esp.Boxes,
        callback = function(state)
            PuppyWare.Visuals.player_esp.Boxes = state
        end
    })
    
    esp_features.toggle({
        name = "Healthbar",
        sub_name = "Show health bars",
        flag = "esp_health",
        Default = PuppyWare.Visuals.player_esp.Healthbar,
        callback = function(state)
            PuppyWare.Visuals.player_esp.Healthbar = state
        end
    })
    
    esp_features.toggle({
        name = "Names",
        sub_name = "Show player names",
        flag = "esp_names",
        Default = PuppyWare.Visuals.player_esp.Names,
        callback = function(state)
            PuppyWare.Visuals.player_esp.Names = state
        end
    })
    
    esp_features.toggle({
        name = "Distance",
        sub_name = "Show player distance",
        flag = "esp_distance_display",
        Default = PuppyWare.Visuals.player_esp.Distance,
        callback = function(state)
            PuppyWare.Visuals.player_esp.Distance = state
        end
    })
    
 

    -- After other visuals settings, add target visuals settings
    target_box.toggle({
        name = "Target Highlight",
        sub_name = "Highlight locked target",
        flag = "target_highlight",
        Default = PuppyWare.Visualization.On_Target.Highlight.Enabled,
        callback = function(state)
            PuppyWare.Visualization.On_Target.Highlight.Enabled = state
        end
    })

    target_box.toggle({
        name = "Target Snapline",
        sub_name = "Draw line to target from mouse",
        flag = "target_snapline",
        Default = PuppyWare.Visualization.On_Target.Snapline.Enabled,
        callback = function(state)
            PuppyWare.Visualization.On_Target.Snapline.Enabled = state
        end
    })

    target_box.toggle({
        name = "Target Tracer",
        sub_name = "Draw line between you and target",
        flag = "target_tracer",
        Default = PuppyWare.Visualization.On_Target.Tracer.Enabled,
        callback = function(state)
            PuppyWare.Visualization.On_Target.Tracer.Enabled = state
        end
    })

    target_box.slider({
        name = "Tracer Thickness",
        min = 1,
        max = 5,
        sub_name = 'Line thickness',
        decimals = 0,
        default = PuppyWare.Visualization.On_Target.Tracer.Thickness,
        flag = "tracer_thickness",
        callback = function(val)
            PuppyWare.Visualization.On_Target.Tracer.Thickness = val
            TargetTracer.Thickness = val
        end
    })

    -- Add notification toggle to the UI
    target_box.toggle({
        name = "Target Notifications",
        sub_name = "Show notification when locked on target",
        flag = "target_notifications",
        Default = PuppyWare.Visualization.On_Target.Notifications.Enabled,
        callback = function(state)
            PuppyWare.Visualization.On_Target.Notifications.Enabled = state
        end
    })


    local input = config_box.input({
        Title = "Enter Config Name",
        Flag = "config_name_input_flag"
    })
    local Selected_Config;
    local config_dd = config_box.dropdown({
        name = "Select Config (.cfg)",
        sub_name = "Select an Existing Config (.cfg)",
        flag = "existing_config_flag",
        max = 1,
        Callback = function(v)
            Selected_Config = v
            print(v.." was selected.")
        end;
    })
    
    config_dd:SetOptions(config_files)
    config_box.button({
        name = "Save Config",
        button_title = "Save",
        flag = "create_config_flag",
        Callback = function()
            local name = library.flags.config_name_input_flag
            if not name or name == "" then return end
            name = name:gsub("[^%w_%-]", "")
    
            save_config(name)
            config_dd:SetOptions(get_config_files())
    
            library.notify({
                Text = name .. " config has been saved",
                Delay = 4
            })
        end
    })
    
    config_box.button({
        name = "Load Config",
        button_title = "Load",
        flag = "load_config_flag",
        Callback = function()
            if type(Selected_Config) == "table" then
                Selected_Config = Selected_Config[1]
            end
    
            if not Selected_Config or Selected_Config == "" then
                library.notify({
                    Text = "No config selected.",
                    Delay = 4
                })
                return
            end
            load_config(Selected_Config)
    
            library.notify({
                Text = tostring(Selected_Config) .. " config has loaded!",
                Delay = 4
            })
        end
    })
 
    Script.Functions.CreateConnection(RunService.Heartbeat, function(Delta) --// Target Visuals \\--
        if Script.Targeting.Target and Script.Targeting.Target.Character then
            library.notify({
                Text = "Locked On " .. Script.Targeting.Target.Name,
                Delay = 4
            })
        end
    end)
    
end)

-- Auto Armor implementation
getgenv().autoArmorEnabled = PuppyWare.Misc.player.AutoArmorEnabled
getgenv().autoFArmorEnabled = PuppyWare.Misc.player.AutoFArmorEnabled
getgenv().armorThreshold = PuppyWare.Misc.player.ArmorThreshold
getgenv().fArmorThreshold = PuppyWare.Misc.player.FArmorThreshold

local player = game:GetService("Players").LocalPlayer
local dataFolder = player:WaitForChild("DataFolder")
local armorInfo = dataFolder:WaitForChild("Information"):FindFirstChild("ArmorSave") or nil
local fireArmorInfo = dataFolder:WaitForChild("Information"):FindFirstChild("FireArmorSave") or nil
local armorShop = workspace.Ignored.Shop["[High-Medium Armor] - $2513"]
local fireArmorShop = workspace.Ignored.Shop["[Fire Armor] - $2623"]
local armorClickDetector = armorShop.ClickDetector
local fireArmorClickDetector = fireArmorShop.ClickDetector
 

local function canBuyArmor()
    local character = player.Character
    if not character then return false end
    local humanoid = character:FindFirstChild("Humanoid")
    if humanoid and humanoid.Health <= 1 then return false end
    local bodyEffects = character:FindFirstChild("BodyEffects")
    local isKO = bodyEffects and bodyEffects:FindFirstChild("K.O") and bodyEffects["K.O"].Value
    if isKO then return false end
    return true
end

local function teleportAndBuy(shop, clickDetector)
    local character = player.Character
    if not character or not character.PrimaryPart then return end

    local originalPosition = character.PrimaryPart.CFrame
    task.wait(0.1)

    character:SetPrimaryPartCFrame(shop.Head.CFrame * CFrame.new(0, 3.1, 0))
    task.wait(0.2)

    fireclickdetector(clickDetector)
    task.wait(0.1)

    character:SetPrimaryPartCFrame(originalPosition)
    task.wait(0.1)
end

local function buyArmor()
    if armorInfo and getgenv().autoArmorEnabled and tonumber(armorInfo.Value) < getgenv().armorThreshold and canBuyArmor() then
        local wasDesyncEnabled = PuppyWare.HvH.Antis.ServerDesynchronization
        if wasDesyncEnabled then
            toggleDesync(false)
        end

        teleportAndBuy(armorShop, armorClickDetector)

        if wasDesyncEnabled then
            toggleDesync(true)
        end
    end
end

local function buyFireArmor()
    if fireArmorInfo and getgenv().autoFArmorEnabled and tonumber(fireArmorInfo.Value) < getgenv().fArmorThreshold and canBuyArmor() then
        local wasDesyncEnabled = PuppyWare.HvH.Antis.ServerDesynchronization
        if wasDesyncEnabled then
            toggleDesync(false)
        end

        teleportAndBuy(fireArmorShop, fireArmorClickDetector)

        if wasDesyncEnabled then
            toggleDesync(true)
        end
    end
end

local function checkArmor()
    while task.wait(0.1) do
        if armorInfo then
            buyArmor()
        end
        if fireArmorInfo then
            buyFireArmor()
        end
    end
end

player.CharacterAdded:Connect(function()
    task.wait(1.4)
    armorInfo = dataFolder:WaitForChild("Information"):FindFirstChild("ArmorSave") or nil
    fireArmorInfo = dataFolder:WaitForChild("Information"):FindFirstChild("FireArmorSave") or nil
    buyArmor()
    buyFireArmor()
end)

task.spawn(checkArmor)

 